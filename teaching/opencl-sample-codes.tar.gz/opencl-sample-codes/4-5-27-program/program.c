#include <stdio.h>
#include <stdlib.h>
#include <error.h>
#include <kernelio.h>
#include <CL/opencl.h>

#define MAX_DEVICES 2
#define MAX_PLATFORMS 2

int main(int argc, char** argv)
{
  cl_int err;
  cl_context context;
  cl_command_queue queue;
  cl_uint numPlatforms;
  cl_platform_id platforms[MAX_PLATFORMS];
  cl_uint numDevices;
  cl_device_id devices[MAX_DEVICES];
  cl_context_properties properties[3]= {0};
  size_t size;
  cl_program program;
  char* source, filename[1000], buildLog[1000];
  size_t sourceLength;
  int i;
  size_t* binaryLengths;
  unsigned char** binaryCodes;
  
  err= clGetPlatformIDs(MAX_PLATFORMS, platforms, &numPlatforms);
  ERROR(err, "clGetPlatformIDs");
  
  properties[0]= (cl_context_properties)CL_CONTEXT_PLATFORM;
  properties[1]= (cl_context_properties)(platforms[0]);
  properties[2]= 0;
  
  context= clCreateContextFromType(properties, CL_DEVICE_TYPE_ALL, &notify, &stderr, &err);
  ERROR(err, "clCreateContextFromType");
  
  err= clGetContextInfo(context, CL_CONTEXT_DEVICES, MAX_DEVICES*sizeof(cl_device_id), devices, &size);
  ERROR(err, "clGetContextInfo");
  err= clGetContextInfo(context, CL_CONTEXT_NUM_DEVICES, sizeof(cl_uint), &numDevices, &size);
  ERROR(err, "clGetContextInfo");
  
  queue= clCreateCommandQueue(context, devices[0], 0, &err);
  ERROR(err, "clCreateCommandQueue");
  
  readSourceProgram("secondOrder.k",                  //name of source file
                    &source,                          //pointer to char pointer
                    &sourceLength);                   //pointer to integer
  
  program= clCreateProgramWithSource(context,         //context object
                                     1,               //number of sources
                                     (void*)&source,  //pointer to source array
                                     &sourceLength,   //pointer to source length array
                                     &err);           //pointer to error code
  ERROR(err, "clCreateProgramWithSource");
  
  err= clBuildProgram(program,                        //program object
                      numDevices,                     //number of devices to build for
                      devices,                        //array of devices to build for
                      "-cl-fast-relaxed-math",        //options
                      NULL,                           //pointer to pfn_notify
                      NULL);                          //user_data
  ERROR(err, "clBuildProgram");

  for ( i= 0; i < numDevices; ++i )
  {
    err= clGetProgramBuildInfo(program,               //program object
                               devices[i],            //device id
                               CL_PROGRAM_BUILD_LOG,  //property
                               1000,                  //max. length of property
                               &(buildLog),           //pointer to property
                               &size);                //actual length of property
    ERROR(err, "clGetProgramBuildInfo");
    printf("%s\n", buildLog);
  }
  
  binaryLengths= (size_t*)malloc(sizeof(size_t)*numDevices);
  binaryCodes= (unsigned char**)malloc(sizeof(unsigned char*)*numDevices);
  
  err= clGetProgramInfo(program,                    //program object
			CL_PROGRAM_BINARY_SIZES,    //property
			sizeof(size_t)*numDevices,  //maximum size of property
			binaryLengths,              //pointer to property
			&size);                     //actual size of property
  ERROR(err, "clGetProgramInfo");
  
  for ( i= 0; i < numDevices; ++i )
    binaryCodes[i]= (unsigned char*)malloc(sizeof(unsigned char)*(binaryLengths[i]));
  
  err= clGetProgramInfo(program,                             //program object
			CL_PROGRAM_BINARIES,                 //property
			sizeof(unsigned char*)*numDevices,   //maximum size of property
			binaryCodes,                         //pointer to property
			&size);                              //actual size of property
  ERROR(err, "clGetProgramInfo");

  writeBinaryProgram("secondOrder.b", binaryCodes, binaryLengths, numDevices);

  clReleaseProgram(program);
  clReleaseCommandQueue(queue);
  clReleaseContext(context);
  
  free(source);
  for ( i= 0; i < numDevices; ++i )
    free(binaryCodes[i]);
  free(binaryCodes);
  free(binaryLengths);
  
  return 0;
}
