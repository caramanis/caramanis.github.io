#include <stdio.h>
#include <string.h>

#include <error.h>
#include <kernelio.h>
#include <stopper.h>
#include <openclinit.h>
#include <pngio.h>

#include <CL/opencl.h>

int main(int argc, char** argv)
{
  cl_int err;
  cl_context context;
  cl_command_queue queue;
  cl_mem imgInMem, imgOutMem, weightsMem, posMem;
  cl_event event;
  cl_program program;
  cl_kernel kernel;
  cl_uint numDevices;
  cl_device_id devices[MAX_DEVICES];
  char* kernelSource;
  size_t kernelLength;
  size_t global_work_size[2];
  unsigned char *imageIn, *imageOut;
  int* pos;
  unsigned int rows, columns, imn, i, n;
  cl_image_format cif;
  cl_image_desc cid;
  size_t origin[3]= {0, 0, 0};
  size_t region[3]= {0, 0, 0};
  float scale= atof(argv[2]);
  int newRows, newColumns;
  
  createContextAndCommandQueue(&context, &queue, devices, &numDevices);
  
  readPNG(argv[1], &imageIn, &rows, &columns);
  newRows= scale*rows;
  newColumns= scale*columns;
  imageOut= (unsigned char*)malloc(sizeof(unsigned char)*4*newRows*newColumns);
  
  cif.image_channel_order= CL_RGBA;
  cif.image_channel_data_type= CL_UNSIGNED_INT8;

  imgInMem= clCreateImage2D(context,                //context object
                            CL_MEM_READ_WRITE,      //flags
                            &cif,                   //image format descriptor
                            columns,                //number of columns
                            rows,                   //number of rows
                            0,                      //row pitch
                            NULL,                   //host pointer
                            &err);                  //error code
  ERROR(err, "clCreateImage2D")
  
  imgOutMem= clCreateImage2D(context,               //context object
                             CL_MEM_READ_WRITE,     //flags
                             &cif,                  //image format descriptor
                             newColumns,            //number of new columns
                             newRows,               //number of new rows
                             0,                     //row pitch
                             NULL,                  //host pointer
                             &err);                 //error code
  ERROR(err, "clCreateImage2D")

  region[0]= columns;
  region[1]= rows;
  region[2]= 1;  
  err= clEnqueueWriteImage(queue,                   //queue object
                           imgInMem,                //image object
                           CL_TRUE,                 //blocking write
                           origin,                  //origin of writing
                           region,                  //region of writing
                           0,                       //row pitch
                           0,                       //slice pitch
                           imageIn,                 //image data
                           0,                       //number of events in the event array
                           NULL,                    //array of events
                           NULL);                   //output event
  ERROR(err, "clEnqueueWriteImage")
  
  readSourceProgram("resampleKernel.k", &kernelSource, &kernelLength);
  program= clCreateProgramWithSource( context, 1, &kernelSource, NULL, &err);
  ERROR(err, "clCreateProgramWithSource")
    
  err= clBuildProgram(program, numDevices, devices, NULL, NULL, NULL);
  ERROR(err, "clBuildProgram")
  
  kernel= clCreateKernel(program, "resample", &err);
  ERROR(err, "clCreateKernel")

  global_work_size[0]= 512;
  global_work_size[1]= 512;  
  
  err= clSetKernelArg(kernel, 0, sizeof(cl_mem), &imgInMem);
  ERROR(err, "clSetKernelArg")
  err= clSetKernelArg(kernel, 1, sizeof(cl_mem), &imgOutMem);
  ERROR(err, "clSetKernelArg")

  err= clEnqueueNDRangeKernel(queue, kernel, 2, NULL, global_work_size, NULL, 0, NULL, &event);
  ERROR(err, "clEnqueueNDRangeKernel")
  
  region[0]= newColumns;
  region[1]= newRows;
  
  err= clEnqueueReadImage(queue,                    //queue object
                          imgOutMem,                //image object
                          CL_TRUE,                  //blocking read
                          origin,                   //origin of reading
                          region,                   //region of reading
                          0,                        //row pitch
                          0,                        //slice pitch
                          imageOut,                 //pointer to allocated region for data
                          1,                        //number of events in the event array
                          &event,                   //array of events
                          NULL);                    //output event
  ERROR(err, "clEnqueueReadImage")
  
  writePNG(argv[3], imageOut, newRows, newColumns);
  
  clReleaseMemObject(imgInMem);
  clReleaseMemObject(imgOutMem);
  clReleaseCommandQueue(queue);
  clReleaseContext(context);
  
  free(imageIn);
  free(imageOut);
  
  return 0;
}