#include <stdio.h>
#include <pngio.h>
#include <stdlib.h>

int main(int argc, char** argv)
{
  unsigned int rows, columns;
  unsigned char* image;
  int i, tmp;
  
  readPNG(argv[1], &image, &rows, &columns);
  
  for ( i= 0; i < rows*columns*3; i+= 3 )
  {
    tmp= image[i];
    image[i]= image[i+1];
    image[i+1]= tmp;
  }
  
  writePNG(argv[2], image, rows, columns);
  
  free(image);
  
  return 0;
}