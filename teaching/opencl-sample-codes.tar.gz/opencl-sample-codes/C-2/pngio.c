#include <stdio.h>
#include <float.h>
#include <string.h>
#include <stdlib.h>

#include <png.h>
#include <pngio.h>

int readPNG(char* filename, unsigned char** img, unsigned int* rows, unsigned int* columns)
{
  int err, i, j;
  png_byte header[8];
  FILE* fp= fopen(filename, "rb");
  png_structp png_ptr;
  png_infop info_ptr;
  png_bytep* row_pointers;
  int colorType, bitDepth;
  
  if ( !fp )
    return -1;
  err= fread(header, 1, 8, fp);
  if ( err != 8 )
    return printf("Cannot read png header!\n");
  
  if ( png_sig_cmp(header, 0, 8) )
    return printf("Not PNG image\n");
  
  if ( !(png_ptr= png_create_read_struct(PNG_LIBPNG_VER_STRING, 0, 0, 0)) )
    return printf("PNG pointer error\n");
  
  info_ptr= png_create_info_struct(png_ptr);
  
  if ( setjmp(png_jmpbuf(png_ptr)) )
    return printf("read_png_file error during init_io\n");
  
  png_init_io(png_ptr, fp);
  png_set_sig_bytes(png_ptr, 8);
  
  png_read_info(png_ptr, info_ptr);
  
  *columns= info_ptr->width;
  *rows= info_ptr->height;
  colorType= info_ptr->color_type;
  bitDepth= info_ptr->bit_depth;
  
  png_read_update_info(png_ptr, info_ptr);
  
  if ( setjmp(png_jmpbuf(png_ptr)) )
    return printf("read_png_file error during read_image\n");
  
  row_pointers= (png_bytep*)malloc(sizeof(png_bytep)*(*rows));
  
  for ( i= 0; i < *rows; ++i )
    row_pointers[i]= (png_byte*)malloc(info_ptr->rowbytes);
  
  png_read_image(png_ptr, row_pointers);
  
  *img= (unsigned char*)malloc(sizeof(unsigned char)*3*(*rows)*(*columns));
  
  if ( colorType == 2 && bitDepth == 8 )
    for ( i= 0; i < *rows; ++i )
       memcpy(*img + i*(info_ptr->rowbytes), row_pointers[i], info_ptr->rowbytes);
   else
    return printf("Unsupported image type\n");
  
  fclose(fp);
  for ( i= 0; i < *rows; ++i )
    free(row_pointers[i]);
  free(row_pointers);
  
  png_destroy_info_struct(png_ptr, &info_ptr);
  png_destroy_read_struct(&png_ptr, &info_ptr, NULL);
  
  return 0;
}

int writePNG(char* filename, unsigned char* img, unsigned int rows, unsigned int columns)
{
  FILE* fp= fopen(filename, "wb");
  png_structp png_ptr;
  png_infop info_ptr;
  png_bytepp row_pointers;
  png_uint_32 rowbytes;
  int i;
  
  if ( !fp )
    return printf("Can't open file\n");
  
  png_ptr= png_create_write_struct(PNG_LIBPNG_VER_STRING, 0, 0,0 );
  
  if ( !png_ptr )
    return printf("png_ptr error\n");
  
  info_ptr= png_create_info_struct(png_ptr);
  
  if ( !info_ptr )
    return printf("info_ptr error\n");
  
  png_init_io(png_ptr, fp);
  
  png_set_compression_level(png_ptr, 0);
  
  png_set_IHDR(png_ptr, info_ptr, columns, rows, 8, PNG_COLOR_TYPE_RGB, PNG_INTERLACE_NONE, PNG_COMPRESSION_TYPE_DEFAULT, PNG_FILTER_TYPE_DEFAULT);
  
  png_write_info(png_ptr, info_ptr);
  
  row_pointers= (png_byte**)png_malloc(png_ptr, rows*sizeof(png_bytep));
  
  for ( i= 0; i < rows; ++i )
    row_pointers[i]= (png_byte*)png_malloc(png_ptr, columns*3*sizeof(png_byte));
  
  rowbytes= 3*columns;
  
  for ( i= 0; i < rows; ++i )
    memcpy(row_pointers[i], img + i*rowbytes, rowbytes);
  
  png_write_rows(png_ptr, row_pointers, rows);
  
  png_write_end(png_ptr, info_ptr);
  
  png_write_flush(png_ptr);
  
  png_destroy_write_struct(&png_ptr, &info_ptr);
  
  for ( i= 0; i < rows; ++i )
    free(row_pointers[i]);
  
  free(row_pointers);
  
  return 0;
}
