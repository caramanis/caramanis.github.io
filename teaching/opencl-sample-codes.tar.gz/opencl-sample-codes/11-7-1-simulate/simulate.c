#include <stdio.h>
#include <string.h>
#include <error.h>
#include <kernelio.h>
#include <stopper.h>
#include <openclinit.h>
#include <CL/opencl.h>

#define MAX_DEVICES 2
#define MAX_PLATFORMS 2

void init(float*r, float* v, float* m, int N)
{
  int i;
  for ( i= 0; i < N; i++ )
  {
    r[3*i]= ((float)rand())/RAND_MAX*2-1;
    r[3*i+1]= ((float)rand())/RAND_MAX*2-1;
    r[3*i+2]= ((float)rand())/RAND_MAX*2-1;
    v[3*i]= v[3*i+1]= v[3*i+2]= 0;
    m[i]= ((float)rand())/RAND_MAX;
  }
}

void writeImage(float* r, int N, float* image, unsigned int rows, unsigned int columns, float* m, int coord0, int coord1, char* filename)
{
  int i;
  int rr, cc;
  for ( i= 0; i < rows*columns; ++i )
    image[i]= 0;
  
  for ( i= 0; i < 3*N; i+= 3 )
  {
    rr= r[i+coord0]*rows/2 + rows/2;
    cc= r[i+coord1]*columns/2 + columns/2;
    if ( rr >= 0 && cc >= 0 && rr < rows && cc < columns )
      image[rr*columns + cc]+= m[i/4];
  }
  writePGM(filename, image, rows, columns);
}

void writeImages(float* r, int N, float* image, unsigned int rows, unsigned int columns, float* m, int idx)
{
  char filename[100];
  
  sprintf(filename, "output01%04d.pgm", idx);
  writeImage(r, N, image, rows, columns, m, 0, 1, filename);
  sprintf(filename, "output02%04d.pgm", idx);
  writeImage(r, N, image, rows, columns, m, 0, 2, filename);
  sprintf(filename, "output12%04d.pgm", idx);
  writeImage(r, N, image, rows, columns, m, 1, 2, filename);
}

int main(int argc, char** argv)
{
  cl_int err;
  cl_context context;
  cl_command_queue queue;
  cl_mem rMem, vMem, mMem, tmpMem;
  cl_event event[2];
  cl_uint numDevices;
  cl_device_id devices[MAX_DEVICES];
  cl_uint numPlatforms;
  cl_platform_id platforms[MAX_PLATFORMS];
  cl_context_properties properties[MAX_PLATFORMS*2]= {0};
  size_t size;
  cl_program program;
  cl_kernel simulationKernel;
  char* kernelSource;
  size_t kernelLength;
  size_t global_work_size[2], local_work_size[2];
  int i, j, k, N= atoi(argv[1]), iterations= atoi(argv[2]);
  float *r, *v, *m, *tmp, dt= atof(argv[3]);
  float* image;
  unsigned int rows= 256, columns= 256;
  char filename[100];
  stopper st;

  r= (float*)malloc(sizeof(float)*N*4);
  v= (float*)malloc(sizeof(float)*N*4);
  tmp= (float*)malloc(sizeof(float)*N*4);  
  m= (float*)malloc(sizeof(float)*N);
  image= (float*)malloc(sizeof(float)*rows*columns);
  
  init(r, v, m, N);

  global_work_size[0]= N;
  if ( N % 256 == 0 )
    local_work_size[0]= 256;
  else if ( N % 4 == 0 )
    local_work_size[0]= N/4;
  else
    local_work_size[0]= 1;

  createContextAndCommandQueue(&context, &queue, devices, &numDevices);
  
  rMem= clCreateBuffer(context, 0, N*3*sizeof(float), NULL, &err);
  ERROR(err, "clCreateBuffer")
  vMem= clCreateBuffer(context, 0, N*3*sizeof(float), NULL, &err);
  ERROR(err, "clCreateBuffer")
  mMem= clCreateBuffer(context, 0, N*sizeof(float), NULL, &err);
  ERROR(err, "clCreateBuffer")
  tmpMem= clCreateBuffer(context, 0, N*3*sizeof(float), NULL, &err);
  ERROR(err, "clCreateBuffer")
  
  readSourceProgram("simulation.k", &kernelSource, &kernelLength);
  program= clCreateProgramWithSource( context, 1, &kernelSource, NULL, &err);
  ERROR(err, "clCreateProgramWithSource")
    
  err= clBuildProgram(program, numDevices, devices, NULL, NULL, NULL);
  ERROR(err, "clBuildProgram")
  
  simulationKernel= clCreateKernel(program, "simulation", &err);
  ERROR(err, "clCreateKernel")

  err= clEnqueueWriteBuffer(queue, rMem, CL_TRUE, 0, sizeof(float)*3*N, r, 0, NULL, NULL);
  ERROR(err, "clEnqueueWriteBuffer")
  err= clEnqueueWriteBuffer(queue, vMem, CL_TRUE, 0, sizeof(float)*3*N, v, 0, NULL, NULL);
  ERROR(err, "clEnqueueWriteBuffer")
  err= clEnqueueWriteBuffer(queue, mMem, CL_TRUE, 0, sizeof(float)*N, m, 0, NULL, NULL);
  ERROR(err, "clEnqueueWriteBuffer")
  
  err= clSetKernelArg(simulationKernel, 0, sizeof(cl_mem), &rMem);
  ERROR(err, "clSetKernelArg")
  err= clSetKernelArg(simulationKernel, 1, sizeof(cl_mem), &vMem);
  ERROR(err, "clSetKernelArg")
  err= clSetKernelArg(simulationKernel, 2, sizeof(cl_mem), &mMem);
  ERROR(err, "clSetKernelArg")
  err= clSetKernelArg(simulationKernel, 3, sizeof(cl_mem), &tmpMem);
  ERROR(err, "clSetKernelArg")
  err= clSetKernelArg(simulationKernel, 4, sizeof(cl_float), &dt);
  ERROR(err, "clSetKernelArg")
  err= clSetKernelArg(simulationKernel, 5, sizeof(cl_float)*3*local_work_size[0], NULL);
  ERROR(err, "clSetKernelArg")

  for ( i= 0; i < iterations; ++i )
  {
    startS(&st);
    err= clEnqueueNDRangeKernel(queue, simulationKernel, 1, NULL, global_work_size, local_work_size, i == 0 ? 0 : 1, i == 0 ? NULL : event + 1, event); 
    ERROR(err, "clEnqueueNDRangeKernel")
    clWaitForEvents(1, event);
    ERROR(err, "clWaitForEvents")
    stopS(&st);
    
    err= clEnqueueCopyBuffer(queue, tmpMem, rMem, 0, 0, sizeof(float)*3*N, 0, NULL, event + 1);
    ERROR(err, "clEnqueueCopyBuffer")
    err= clEnqueueReadBuffer(queue, rMem, CL_TRUE, 0, sizeof(float)*3*N, r, 0, NULL, NULL);
    ERROR(err, "clEnqueueReadBuffer")
    
    writeImages(r, N, image, rows, columns, m, i);
  }

  clReleaseMemObject(rMem);
  clReleaseMemObject(vMem);
  clReleaseMemObject(tmpMem);
  clReleaseMemObject(mMem);
  clReleaseKernel(simulationKernel);
  clReleaseProgram(program);
  clReleaseCommandQueue(queue);
  clReleaseContext(context);
  
  free(kernelSource);
  free(r);
  free(v);
  free(tmp);
  free(m);
  
  tprintf(&st, "%d\n", N);
  
  return 0;
}