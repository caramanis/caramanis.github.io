#include <stdio.h>
#include <string.h>
#include <error.h>
#include <kernelio.h>
#include <CL/opencl.h>

#define ARRAY_SIZE 20
#define MAX_DEVICES 2
#define MAX_PLATFORMS 2

int main(int argc, char** argv)
{
  cl_int err;
  cl_context context;
  cl_command_queue queue;
  cl_mem memobjInput;
  float input[ARRAY_SIZE];
  int i;
  cl_event event;
  cl_uint numDevices;
  cl_device_id devices[MAX_DEVICES];
  cl_uint numPlatforms;
  cl_platform_id platforms[MAX_PLATFORMS];
  cl_context_properties properties[MAX_PLATFORMS*2]= {0};
  cl_program program;
  cl_kernel kernel;
  char* kernelSource;
  size_t kernelLength, size;
  
  for ( i= 0; i < ARRAY_SIZE; ++i )
    input[i]= i;

  err= clGetPlatformIDs(MAX_PLATFORMS, platforms, &numPlatforms);
  ERROR(err, "clGetPlatformIDs")  

  for ( i= 0; i < numPlatforms; ++i )
  {
    properties[i*2]= (cl_context_properties)CL_CONTEXT_PLATFORM;
    properties[i*2 + 1]= (cl_context_properties)(platforms[i]);
  }
  properties[i*2]= 0;
  
  context= clCreateContextFromType(properties, CL_DEVICE_TYPE_ALL, NULL, NULL, &err);
  ERROR(err, "clCreateContextFromType")
  
  err= clGetContextInfo(context, CL_CONTEXT_DEVICES, MAX_DEVICES*sizeof(cl_device_id), devices, &size);
  ERROR(err, "clGetContextInfo")
  err= clGetContextInfo(context, CL_CONTEXT_NUM_DEVICES, sizeof(cl_uint), &numDevices, &size);
  ERROR(err, "clGetContextInfo")
  
  queue= clCreateCommandQueue(context, devices[0], 0, &err);
  ERROR(err, "clCreateCommandQueue")
  
  memobjInput= clCreateBuffer(context, 0, ARRAY_SIZE * sizeof(float), NULL, &err);
  ERROR(err, "clCreateBuffer")
  
  readSourceProgram("sqrtKernel.k", &kernelSource, &kernelLength);
  program= clCreateProgramWithSource( context, 1, &kernelSource, NULL, &err);
  ERROR(err, "clCreateProgramWithSource")
    
  err= clBuildProgram(program, numDevices, devices, NULL, NULL, NULL);
  ERROR(err, "clBuildProgram")
  
  kernel= clCreateKernel(program, "sqrtKernel", &err);
  ERROR(err, "clCreateKernel")

  err= clEnqueueWriteBuffer(queue, memobjInput, 1, 0, sizeof(float)*ARRAY_SIZE, input, 0, NULL, &event);
  ERROR(err, "clEnqueueWriteBuffer")
  
  err= clSetKernelArg(kernel, 0, sizeof(memobjInput), &memobjInput);
  ERROR(err, "clSetKernelArg")
  
  size_t global_work_offset= 0;
  size_t global_work_size= ARRAY_SIZE;
  err= clEnqueueNDRangeKernel(queue,               //command queue
                              kernel,              //kernel
                              1,                   //dimensions
                              &global_work_offset, //global index offset
                              &global_work_size,   //global work size
                              NULL,                //local work size
                              0,                   //number of events
                              NULL,                //array of events
                              &event);             //output event
  ERROR(err, "clEnqueueNDRangeKernel")
  
  err= clWaitForEvents(1, &event);
  ERROR(err, "clWaitForEvents")

  err= clEnqueueReadBuffer(queue, memobjInput, 1, 0, sizeof(float)*ARRAY_SIZE, input, 0, NULL, &event);
  ERROR(err, "clEnqueueReadBuffer")
  
  err= clWaitForEvents(1, &event);
  ERROR(err, "clWaitForEvents");
  
  for ( i= 0; i < ARRAY_SIZE; ++i )
    printf("%f ", input[i]);
  printf("\n");
  
  clReleaseMemObject(memobjInput);
  clReleaseKernel(kernel);
  clReleaseProgram(program);
  clReleaseCommandQueue(queue);
  clReleaseContext(context);
  
  free(kernelSource);
  
  return 0;
}