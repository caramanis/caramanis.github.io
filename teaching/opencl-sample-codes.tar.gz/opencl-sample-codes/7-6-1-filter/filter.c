#include <filter.h>
#include <math.h>

#define MIN(a,b) (a<b?a:b)

void generateGaussianFilter(float sigma, int block_size, int* f2, float** weights, int** positions, unsigned int* n)
{
  int min, max;
  int i, j, k= 0;
  float c= 2*sigma*sigma;
  int columns;
  //printf("%f %d\n", sigma, *f2);
  *f2= MIN(3*sigma, *f2);
  min= -(*f2), max= *f2;
  columns= block_size + 2*(*f2);
  
  *weights= (float*)malloc(sizeof(float)*MAX_FILTER_SIZE);
  *positions= (int*)malloc(sizeof(int)*MAX_FILTER_SIZE);

  for ( i= min; i <= max; ++i )
    for ( j= min; j <= max; ++j )
      if ( i*i + j*j <= 9*sigma*sigma )
      {
        (*weights)[k]= 1.0/(M_PI*c)*exp(-(i*i + j*j)/c);
        (*positions)[k++]= i*columns + j;
      }

  *n= k;
  *weights= (float*)realloc(*weights, sizeof(float)*k);
  *positions= (int*)realloc(*positions, sizeof(int)*k);
}
