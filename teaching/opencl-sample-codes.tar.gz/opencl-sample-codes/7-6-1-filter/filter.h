#ifndef _FILTER_H_
#define _FILTER_H_

#define MAX_FILTER_SIZE 100000

#include <stdlib.h>

void generateGaussianFilter(float sigma, int block_size, int* f2, float** weights, int** positions, unsigned int* n);

#endif