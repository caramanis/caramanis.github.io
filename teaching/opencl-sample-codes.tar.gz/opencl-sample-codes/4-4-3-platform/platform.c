#include <stdio.h>
#include <error.h>
#include <CL/opencl.h>

#define MAX_PLATFORMS 10
#define MAX_DEVICES 10
#define MAX_STRING_SIZE 1000

int main(int argc, char** argv)
{
  cl_int err;
  cl_uint numPlatforms;
  cl_platform_id platforms[MAX_PLATFORMS];
  char pString[MAX_STRING_SIZE];
  size_t size;
  int i;

  err= clGetPlatformIDs(MAX_PLATFORMS,    //size of array platforms
                        platforms,        //array of cl_platform_id
                        &numPlatforms);   //number of returned platform ids
  ERROR(err, "clGetPlatformIDs");

  printf("Number of platforms: %d\n", numPlatforms);
  for ( i= 0; i < numPlatforms; ++i )
  {
    err= clGetPlatformInfo(platforms[i],            //platform id
                           CL_PLATFORM_NAME,        //property
                           MAX_STRING_SIZE,         //max size of property
                           &pString,                //address of property
                           &size);                  //number of returned bytes
    ERROR(err, "clGetPlatformInfo");
    printf("Platform name: %s\n", pString);
    
    err= clGetPlatformInfo(platforms[i],            //platform id
                           CL_PLATFORM_VENDOR,      //property
                           MAX_STRING_SIZE,         //max size of property
                           &pString,                //address of property
                           &size);                  //number of returned bytes
    ERROR(err, "clGetPlatformInfo");
    printf("Platform vendor: %s\n", pString);
    
    err= clGetPlatformInfo(platforms[i],            //platform id
                           CL_PLATFORM_VERSION,     //property
                           MAX_STRING_SIZE,         //max size of property
                           &pString,                //address of property
                           &size);                  //number of returned bytes
    ERROR(err, "clGetPlatformInfo");
    printf("Platform version: %s\n", pString);
    
    err= clGetPlatformInfo(platforms[i],            //platform id
                           CL_PLATFORM_PROFILE,     //property
                           MAX_STRING_SIZE,         //max size of property
                           &pString,                //address of property
                           &size);                  //number of returned bytes
    ERROR(err, "clGetPlatformInfo");
    printf("Platform profile: %s\n", pString);
    
    err= clGetPlatformInfo(platforms[i],            //platform id
                           CL_PLATFORM_EXTENSIONS,  //property
                           MAX_STRING_SIZE,         //max size of property
                           &pString,                //address of property
                           &size);                  //number of returned bytes
    ERROR(err, "clGetPlatformInfo");
    printf("Platform extensions: %s\n", pString);
  }
   
  return 0;
}