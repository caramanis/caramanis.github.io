#include <stdio.h>
#include <error.h>

void errorMessage(FILE* o, int err, const char* p)
{
  switch(err)
  {
    case CL_DEVICE_NOT_FOUND: fprintf(o, "%s: Device not found.\n", p); break;
    case CL_DEVICE_NOT_AVAILABLE: fprintf(o, "%s: Device not available.\n", p); break;
    case CL_COMPILER_NOT_AVAILABLE: fprintf(o, "%s: Compiler not available.\n", p); break;
    case CL_MEM_OBJECT_ALLOCATION_FAILURE: fprintf(o, "%s: Mem. obj. app. fail.\n", p); break;
    case CL_OUT_OF_RESOURCES: fprintf(o, "%s: Out of resources.\n", p); break;
    case CL_OUT_OF_HOST_MEMORY: fprintf(o, "%s: Out of host memory.\n", p); break;
    case CL_PROFILING_INFO_NOT_AVAILABLE: fprintf(o, "%s: Prof. info. not avail.\n", p); break;
    case CL_MEM_COPY_OVERLAP: fprintf(o, "%s: Memory copy overlap.\n", p); break;
    case CL_IMAGE_FORMAT_MISMATCH: fprintf(o, "%s: Image format mismatch.\n", p); break;
    case CL_IMAGE_FORMAT_NOT_SUPPORTED: fprintf(o, "%s: Img form. not supported.\n", p); break;
    case CL_BUILD_PROGRAM_FAILURE: fprintf(o, "%s: Program build failure.\n", p); break;
    case CL_MAP_FAILURE: fprintf(o, "%s: Map failure.\n", p); break;
    case CL_INVALID_VALUE: fprintf(o, "%s: Invalid value.\n", p); break;
    case CL_INVALID_DEVICE_TYPE: fprintf(o, "%s: Invalid device type.\n", p); break;
    case CL_INVALID_PLATFORM: fprintf(o, "%s: Invalid platform.\n", p); break;
    case CL_INVALID_DEVICE: fprintf(o, "%s: Invalid device.\n", p); break;
    case CL_INVALID_CONTEXT: fprintf(o, "%s: Invalid context.\n", p); break;
    case CL_INVALID_QUEUE_PROPERTIES: fprintf(o, "%s: Invalid queue properties.\n", p); break;
    case CL_INVALID_COMMAND_QUEUE: fprintf(o, "%s: Invalid command queue.\n", p); break;
    case CL_INVALID_HOST_PTR: fprintf(o, "%s: Invalid host pointer.\n", p); break;
    case CL_INVALID_MEM_OBJECT: fprintf(o, "%s: Invalid memory object.\n", p); break;
    case CL_INVALID_IMAGE_FORMAT_DESCRIPTOR: fprintf(o, "%s: Invalid img format\n", p); break;
    case CL_INVALID_IMAGE_SIZE: fprintf(o, "%s: Invalid image size.\n", p); break;
    case CL_INVALID_SAMPLER: fprintf(o, "%s: Invalid sampler.\n", p); break;
    case CL_INVALID_BINARY: fprintf(o, "%s: Invalid binary.\n", p); break;
    case CL_INVALID_BUILD_OPTIONS: fprintf(o, "%s: Invalid build options.\n", p); break;
    case CL_INVALID_PROGRAM: fprintf(o, "%s: Invalid program.\n", p); break;
    case CL_INVALID_PROGRAM_EXECUTABLE: fprintf(o, "%s: Invalid program exec.\n", p); break;
    case CL_INVALID_KERNEL_NAME: fprintf(o, "%s: Invalid kernel name.\n", p); break;
    case CL_INVALID_KERNEL_DEFINITION: fprintf(o, "%s: Invalid kernel def.\n", p); break;
    case CL_INVALID_KERNEL: fprintf(o, "%s: Invalid kernel.\n", p); break;
    case CL_INVALID_ARG_INDEX: fprintf(o, "%s: Invalid argument index.\n", p); break;
    case CL_INVALID_ARG_VALUE: fprintf(o, "%s: Invalid argument value.\n", p); break;
    case CL_INVALID_ARG_SIZE: fprintf(o, "%s: Invalid argument size.\n", p); break;
    case CL_INVALID_KERNEL_ARGS: fprintf(o, "%s: Invalid kernel arguments.\n", p); break;
    case CL_INVALID_WORK_DIMENSION: fprintf(o, "%s: Invalid work dimension.\n", p); break;
    case CL_INVALID_WORK_GROUP_SIZE: fprintf(o, "%s: Invalid work group size.\n", p); break;
    case CL_INVALID_WORK_ITEM_SIZE: fprintf(o, "%s: Invalid work item size.\n", p); break;
    case CL_INVALID_GLOBAL_OFFSET: fprintf(o, "%s: Invalid global offset.\n", p); break;
    case CL_INVALID_EVENT_WAIT_LIST: fprintf(o, "%s: Invalid event wait list.\n", p); break;
    case CL_INVALID_EVENT: fprintf(o, "%s: Invalid event.\n", p); break;
    case CL_INVALID_OPERATION: fprintf(o, "%s: Invalid operation.\n", p); break;
    case CL_INVALID_GL_OBJECT: fprintf(o, "%s: Invalid OpenGL object.\n", p); break;
    case CL_INVALID_BUFFER_SIZE: fprintf(o, "%s: Invalid buffer size.\n", p); break;
    case CL_INVALID_MIP_LEVEL: fprintf(o, "%s: Invalid mip-map level.\n", p); break;
    default: fprintf(o, "%s: Unknown error.\n", p); break;
  }
  fflush(o);
}