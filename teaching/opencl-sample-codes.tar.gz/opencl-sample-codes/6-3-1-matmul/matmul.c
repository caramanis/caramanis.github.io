#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stopper.h>

void printSM(float* m, int n)
{
  int i, j;
  for ( i= 0; i < n; ++i )
  {
    for ( j= 0; j < n; ++j )
      printf("%.0f ", m[i*n + j]);
    printf("\n");
  }
  printf("\n");
}

int main(int argc, char** argv)
{
  int i, j, k, n;
  float *A, *B, *C;
  
  n= atoi(argv[1]);

  A= (float*)malloc(sizeof(float)*n*n);
  B= (float*)malloc(sizeof(float)*n*n);
  C= (float*)malloc(sizeof(float)*n*n);  
  
  for ( i= 0; i < n*n; ++i )
  {
    A[i]= rand()%10;
    B[i]= rand()%10;
  }

  stopper st;
  startS(&st);
  
  for ( i= 0; i < n; ++i )
    for ( j= 0; j < n; ++j )
    {
      C[i*n + j]= 0;
      for ( k= 0; k < n; ++k )
        C[i*n + j]+= A[i*n + k]*B[k*n + j];
    }
  
  stopS(&st);
  
/*  printSM(A, n);
  printSM(B, n);
  printSM(C, n);*/

  free(A);
  free(B);
  free(C);
  
  tprintf(&st, "%d\n", n);
  
  return 0;
}