#include <stdio.h>
#include <string.h>
#include <error.h>
#include <kernelio.h>
#include <stopper.h>
#include <openclinit.h>
#include <CL/opencl.h>

#define MAX_DEVICES 2
#define MAX_PLATFORMS 2

void printF(float* m, int N)
{
  int i;
  for ( i= 0; i < 2*N; i+= 2 )
    printf("(%.1f, %.1f) ", m[i], m[i+1]);
  printf("\n");
}

int setLocalWorkSize(int gWS, int maxWG)
{
  if ( gWS < 4 )
    return 1;
  if ( gWS/4 <= maxWG )
    return gWS/4;
  return maxWG;
}

int main(int argc, char** argv)
{
  cl_int err;
  cl_context context;
  cl_command_queue queue;
  cl_mem fMem, FMem, gMem;
  cl_event event[2];
  cl_uint numDevices;
  cl_device_id devices[MAX_DEVICES];
  cl_uint numPlatforms;
  cl_platform_id platforms[MAX_PLATFORMS];
  cl_context_properties properties[MAX_PLATFORMS*2]= {0};
  size_t size;
  cl_program program;
  cl_kernel dftKernel, idftKernel;
  char* kernelSource;
  size_t kernelLength;
  size_t global_work_size[2];
  size_t local_work_size[2];
  cl_mem *input, *output;
  char flags[100];
  unsigned int j, k, N;
  int p, i;
  float *f, *F, *g;
  
  N= atoi(argv[1]);
  p= N/2;
  
  f= (float*)malloc(sizeof(float)*2*N);
  g= (float*)malloc(sizeof(float)*2*N);
  F= (float*)malloc(sizeof(float)*2*N);
  
  for ( i= 0; i < 2*N; i+= 2 )
  {
    f[i]= rand()%10;
    f[i+1]= F[i]= F[i+1]= g[i]= g[i+1]= 0;
  }
  
  global_work_size[0]= p;
  local_work_size[0]= setLocalWorkSize(global_work_size[0], 512);
  
  createContextAndCommandQueue(&context, &queue, devices, &numDevices);
  
  fMem= clCreateBuffer(context, 0, N*2*sizeof(float), NULL, &err);
  ERROR(err, "clCreateBuffer")
  FMem= clCreateBuffer(context, 0, N*2*sizeof(float), NULL, &err);
  ERROR(err, "clCreateBuffer")
  gMem= clCreateBuffer(context, 0, N*2*sizeof(float), NULL, &err);
  ERROR(err, "clCreateBuffer")
  
  readSourceProgram("dftKernel.k", &kernelSource, &kernelLength);
  program= clCreateProgramWithSource( context, 1, &kernelSource, NULL, &err);
  ERROR(err, "clCreateProgramWithSource")
  
  sprintf(flags, "-DLOCALSIZE=%zd", local_work_size[0]*2);
  err= clBuildProgram(program, numDevices, devices, flags, NULL, NULL);
  ERROR(err, "clBuildProgram")
  
  dftKernel= clCreateKernel(program, "fft", &err);
  ERROR(err, "clCreateKernel")
  idftKernel= clCreateKernel(program, "ifft", &err);
  ERROR(err, "clCreateKernel")

  err= clEnqueueWriteBuffer(queue, fMem, CL_TRUE, 0, sizeof(float)*2*N, f, 0, NULL, NULL);
  ERROR(err, "clEnqueueWriteBuffer")
  err= clEnqueueWriteBuffer(queue, FMem, CL_TRUE, 0, sizeof(float)*2*N, F, 0, NULL, NULL);
  ERROR(err, "clEnqueueWriteBuffer")
  err= clEnqueueWriteBuffer(queue, gMem, CL_TRUE, 0, sizeof(float)*2*N, g, 0, NULL, NULL);
  ERROR(err, "clEnqueueWriteBuffer")
  
  input= &fMem;
  output= &FMem;

  // computing FFT
  
  stopper st;
  startS(&st);
  
  for ( i= 1; i <= p; i= i * local_work_size[0]*2 )
  {
    while ( local_work_size[0] != 1 && i*local_work_size[0]*2 > p )
      local_work_size[0]>>= 1;
    
    err= clSetKernelArg(dftKernel, 0, sizeof(cl_mem), input);
    ERROR(err, "clSetKernelArg 0")
    err= clSetKernelArg(dftKernel, 1, sizeof(cl_mem), output);
    ERROR(err, "clSetKernelArg 1")

    err= clSetKernelArg(dftKernel, 2, sizeof(cl_int), &i);
    ERROR(err, "clSetKernelArg")
    
    err= clEnqueueNDRangeKernel(queue, dftKernel, 1, NULL, global_work_size, local_work_size, (i == 1 ) ? 0 : 1, (i == 1) ? NULL : event + (i+1)%2, event+(i)%2); 
    ERROR(err, "clEnqueueNDRangeKernel")
    
    input= (input == &fMem) ? &FMem : &fMem;
    output= (output == &fMem) ? &FMem : &fMem;
  }
  clWaitForEvents(1, event + (i+1)%2);
  ERROR(err, "clWaitForEvents")
  stopS(&st);
  
  err= clEnqueueReadBuffer(queue, *input, CL_TRUE, 0, sizeof(float)*2*N, F, 0, NULL, NULL);
  ERROR(err, "clEnqueueReadBuffer")
  if ( input != &FMem )
  {
    err= clEnqueueCopyBuffer(queue, *input, FMem, 0, 0, sizeof(float)*2*N, 0, NULL, event);
    ERROR(err, "clEnqueueReadBuffer")
    clWaitForEvents(1, event);
    ERROR(err, "clWaitForEvents")
  }
  
  input= &FMem;
  output= &gMem;
  local_work_size[0]= setLocalWorkSize(global_work_size[0], 512);
  
  // computing iFFT
  
  for ( i= 1; i <= p; i= i * local_work_size[0]*2 )
  {
    while ( local_work_size[0] != 1 && i*local_work_size[0]*2 > p )
      local_work_size[0]>>= 1;
    
    err= clSetKernelArg(idftKernel, 0, sizeof(cl_mem), input);
    ERROR(err, "clSetKernelArg")
    err= clSetKernelArg(idftKernel, 1, sizeof(cl_mem), output);
    ERROR(err, "clSetKernelArg")

    err= clSetKernelArg(idftKernel, 2, sizeof(cl_int), &i);
    ERROR(err, "clSetKernelArg")
    err= clEnqueueNDRangeKernel(queue, idftKernel, 1, NULL, global_work_size, local_work_size, (i == 1 ) ? 0 : 1, (i == 1) ? NULL : event + (i+1)%2, event+(i)%2); 
    ERROR(err, "clEnqueueNDRangeKernel")

    while ( local_work_size[0] != 1 && i*local_work_size[0]*2 > p )
      local_work_size[0]>>= 1;
    input= (input == &FMem) ? &gMem : &FMem;
    output= (output == &FMem) ? &gMem : &FMem;
  }

  err= clEnqueueReadBuffer(queue, *input, CL_TRUE, 0, sizeof(float)*2*N, g, 1, event + (i+1)%2, NULL);
  ERROR(err, "clEnqueueReadBuffer")
  
/*  printF(f, N);
  printF(F, N);
  printF(g, N);*/
  
  clReleaseMemObject(fMem);
  clReleaseMemObject(FMem);
  clReleaseMemObject(gMem);
  clReleaseKernel(dftKernel);
  clReleaseKernel(idftKernel);
  clReleaseProgram(program);
  clReleaseCommandQueue(queue);
  clReleaseContext(context);
  
  free(kernelSource);
  free(f);
  free(F);
  free(g);
  
  tprintf(&st, "%d\n", N);
  
  return 0;
}