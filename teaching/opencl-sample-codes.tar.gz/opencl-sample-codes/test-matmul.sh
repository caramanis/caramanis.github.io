#! /bin/bash

PARAMETERS="2 4 8 16 32 64 128 356 384 512 640 768 896 1024"
REPEATS=3
POSTFIX=matmul
OUTPUTDIR=test-${POSTFIX}-results

rm -rf ${OUTPUTDIR}
mkdir ${OUTPUTDIR}

for I in `ls -d *-${POSTFIX}`
do
  cd ${I}
  make clean
  rm CMakeCache.txt
  cmake -DCMAKE_BUILD_TYPE=release -r .
  make
  cd ..

  OUTPUTFILE=${I}-results.txt
  touch ${OUTPUTDIR}/${OUTPUTFILE}
  cd ${I}
  for P in ${PARAMETERS}
  do
    for R in `seq 1 1 ${REPEATS}`
    do
      COMMAND="./${POSTFIX} ${P}"
      echo "command: ${COMMAND}"
      ${COMMAND} >> ../${OUTPUTDIR}/${OUTPUTFILE}
    done
  done
  cd ..
done

cp figures-${POSTFIX}.R ${OUTPUTDIR}
cd ${OUTPUTDIR}
Rscript figures-${POSTFIX}.R ${REPEATS}
cd ..