#! /bin/bash

PARAMETERS="2 4 8 12 16 20 24"
REPEATS=3
POSTFIX=filter
OUTPUTDIR=test-${POSTFIX}-results

rm -rf ${OUTPUTDIR}
mkdir ${OUTPUTDIR}

for I in `ls -d *-${POSTFIX}`
do
  cd ${I}
  make clean
  rm CMakeCache.txt
  cmake -DCMAKE_BUILD_TYPE=release -r .
  make
  cd ..

  OUTPUTFILE=${I}-results.txt
  touch ${OUTPUTDIR}/${OUTPUTFILE}
  cd ${I}
  for P in ${PARAMETERS}
  do
    for R in `seq 1 1 ${REPEATS}`
    do
      COMMAND="./${POSTFIX} lena512.pgm ${P} lenaout.pgm"
      echo "${COMMAND}"
      ${COMMAND} >> ../${OUTPUTDIR}/${OUTPUTFILE}
    done
  done
  cd ..
done

cp figures-${POSTFIX}.R ${OUTPUTDIR}
cd ${OUTPUTDIR}
Rscript figures-${POSTFIX}.R ${REPEATS}
cd ..