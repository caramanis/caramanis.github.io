#include <stdio.h>
#include <string.h>
#include <error.h>
#include <kernelio.h>
#include <CL/opencl.h>
#include <time.h>
#include <math.h>

#define ARRAY_SIZE 200
#define MAX_DEVICES 2
#define MAX_PLATFORMS 2

#define THREADS 4

typedef struct parameters
{
  int begin, end;
  float* buffer;
} parameters;

void sqrtKernel(void* a)
{
  parameters* p= (parameters*)a;
  int i;
  
  for ( i= p->begin; i < p->end; ++i )
    p->buffer[i]= sqrt(p->buffer[i]);
}

int main(int argc, char** argv)
{
  cl_int err;
  cl_context context;
  cl_command_queue queue[THREADS];
  cl_mem memobjInput;
  float input[ARRAY_SIZE];
  int i;
  cl_event event[THREADS];
  cl_uint numDevices;
  cl_device_id devices[MAX_DEVICES];
  cl_uint numPlatforms;
  cl_platform_id platforms[MAX_PLATFORMS];
  cl_context_properties properties[MAX_PLATFORMS*2]= {0};
  size_t size;
  const void* arrayPointer;
  parameters p[THREADS];
  cl_device_id subdevices[THREADS];
  cl_device_partition_property subdeviceProperties[THREADS+3];
  
  for ( i= 0; i < ARRAY_SIZE; ++i )
    input[i]= i;

  err= clGetPlatformIDs(MAX_PLATFORMS, platforms, &numPlatforms);
  ERROR(err, "clGetPlatformIDs")  

  for ( i= 0; i < numPlatforms; ++i )
  {
    properties[i*2]= (cl_context_properties)CL_CONTEXT_PLATFORM;
    properties[i*2 + 1]= (cl_context_properties)(platforms[i]);
  }
  properties[i*2]= 0;
  
  context= clCreateContextFromType(properties, CL_DEVICE_TYPE_CPU, NULL, NULL, &err);
  ERROR(err, "clCreateContextFromType")
  
  err= clGetContextInfo(context, CL_CONTEXT_DEVICES, MAX_DEVICES*sizeof(cl_device_id), devices, &size);
  ERROR(err, "clGetContextInfo")
  err= clGetContextInfo(context, CL_CONTEXT_NUM_DEVICES, sizeof(cl_uint), &numDevices, &size);
  ERROR(err, "clGetContextInfo")
  
  subdeviceProperties[0]= CL_DEVICE_PARTITION_BY_COUNTS;
  for ( i= 1; i < THREADS+1; ++i )
    subdeviceProperties[i]= 1;
  subdeviceProperties[i++]= CL_DEVICE_PARTITION_BY_COUNTS_LIST_END;
  subdeviceProperties[i++]= 0;
  err= clCreateSubDevices(devices[0], subdeviceProperties, THREADS, subdevices, &size);
  ERROR(err, "clCreateSubDevices");

  for ( i= 0; i < THREADS; ++i )
  {
    queue[i]= clCreateCommandQueue(context, subdevices[i], CL_QUEUE_OUT_OF_ORDER_EXEC_MODE_ENABLE, &err);
    ERROR(err, "clCreateCommandQueue")
  }
  
  memobjInput= clCreateBuffer(context, CL_MEM_USE_HOST_PTR, ARRAY_SIZE * sizeof(float), (void*)&input, &err);
  ERROR(err, "clCreateBuffer")

  for ( i= 0; i < THREADS; ++i )
  {
    p[i].begin= ((float)ARRAY_SIZE)/THREADS*i;
    p[i].end= ((float)ARRAY_SIZE)/THREADS*(i+1);
    arrayPointer= &(p[i].buffer);
    
    err= clEnqueueNativeKernel(queue[i], 
                               &sqrtKernel, 
                               p + i, 
                               sizeof(p),
                               1,
                               &memobjInput,
                               &arrayPointer,
                               0,
                               NULL,
                               event + i);
    ERROR(err, "clEnqueueNativeKernel")
  }
  
  err= clWaitForEvents(THREADS, event);
  ERROR(err, "clWaitForEvents")

  err= clEnqueueReadBuffer(queue[0], memobjInput, 1, 0, sizeof(float)*ARRAY_SIZE, input, 0, NULL, &event);
  ERROR(err, "clEnqueueReadBuffer")
  
  err= clWaitForEvents(1, &event);
  ERROR(err, "clWaitForEvents");
  
  for ( i= 0; i < ARRAY_SIZE; ++i )
    printf("%f ", input[i]);
  printf("\n");
  
  clReleaseMemObject(memobjInput);
  for ( i= 0; i < THREADS; ++i )
  {
    clReleaseCommandQueue(queue[i]);
    clReleaseDevice(subdevices[i]);
  }
  clReleaseContext(context);
  
  return 0;
}