#include <stdio.h>
#include <string.h>
#include <error.h>
#include <kernelio.h>
#include <stopper.h>
#include <openclinit.h>
#include <CL/opencl.h>

#define MAX_DEVICES 2
#define MAX_PLATFORMS 2

void printF(float* m, int N)
{
  int i;
  for ( i= 0; i < 2*N; i+= 2 )
    printf("(%.1f, %.1f) ", m[i], m[i+1]);
  printf("\n");
}

int main(int argc, char** argv)
{
  cl_int err;
  cl_context context;
  cl_command_queue queue;
  cl_mem fMem, FMem, gMem;
  cl_event event[2];
  cl_uint numDevices;
  cl_device_id devices[MAX_DEVICES];
  cl_uint numPlatforms;
  cl_platform_id platforms[MAX_PLATFORMS];
  cl_context_properties properties[MAX_PLATFORMS*2]= {0};
  size_t size;
  cl_program program;
  cl_kernel dftKernel, idftKernel;
  char* kernelSource;
  size_t kernelLength;
  size_t global_work_size[2];
  size_t local_work_size[2];
  
  unsigned int i, j, k, N;
  float *f, *F, *g;
  
  N= atoi(argv[1]);
  
  f= (float*)malloc(sizeof(float)*2*N);
  g= (float*)malloc(sizeof(float)*2*N);
  F= (float*)malloc(sizeof(float)*2*N);
  
  for ( i= 0; i < 2*N; i+= 2 )
  {
    f[i]= rand()%10;
    f[i+1]= 0;
  }
  
  global_work_size[0]= N;

  createContextAndCommandQueue(&context, &queue, devices, &numDevices);
  
  fMem= clCreateBuffer(context, 0, N*2*sizeof(float), NULL, &err);
  ERROR(err, "clCreateBuffer")
  FMem= clCreateBuffer(context, 0, N*2*sizeof(float), NULL, &err);
  ERROR(err, "clCreateBuffer")
  gMem= clCreateBuffer(context, 0, N*2*sizeof(float), NULL, &err);
  ERROR(err, "clCreateBuffer")
  
  readSourceProgram("dftKernel.k", &kernelSource, &kernelLength);
  program= clCreateProgramWithSource( context, 1, &kernelSource, NULL, &err);
  ERROR(err, "clCreateProgramWithSource")
    
  err= clBuildProgram(program, numDevices, devices, NULL, NULL, NULL);
  ERROR(err, "clBuildProgram")
  
  dftKernel= clCreateKernel(program, "dft", &err);
  ERROR(err, "clCreateKernel")
  idftKernel= clCreateKernel(program, "idft", &err);
  ERROR(err, "clCreateKernel")

  err= clEnqueueWriteBuffer(queue, fMem, CL_TRUE, 0, sizeof(float)*2*N, f, 0, NULL, NULL);
  ERROR(err, "clEnqueueWriteBuffer")
  
  err= clSetKernelArg(dftKernel, 0, sizeof(cl_mem), &fMem);
  ERROR(err, "clSetKernelArg")
  err= clSetKernelArg(dftKernel, 1, sizeof(cl_mem), &FMem);
  ERROR(err, "clSetKernelArg")
  err= clSetKernelArg(idftKernel, 0, sizeof(cl_mem), &FMem);
  ERROR(err, "clSetKernelArg")
  err= clSetKernelArg(idftKernel, 1, sizeof(cl_mem), &gMem);
  ERROR(err, "clSetKernelArg")
  
  stopper st;
  startS(&st);
  err= clEnqueueNDRangeKernel(queue, dftKernel, 1, NULL, global_work_size, NULL, 0, NULL, event); 
  ERROR(err, "clEnqueueNDRangeKernel")
  clWaitForEvents(1, event);
  ERROR(err, "clWaitForEvents")
  stopS(&st);
  
  err= clEnqueueNDRangeKernel(queue, idftKernel, 1, NULL, global_work_size, NULL, 1, event, event+1);

  err= clEnqueueReadBuffer(queue, gMem, CL_TRUE, 0, sizeof(float)*2*N, g, 1, event + 1, NULL);
  ERROR(err, "clEnqueueReadBuffer")
  err= clEnqueueReadBuffer(queue, FMem, CL_TRUE, 0, sizeof(float)*2*N, F, 0, NULL, NULL);
  ERROR(err, "clEnqueueReadBuffer")
  
/*  printF(f, N);
  printF(F, N);
  printF(g, N);*/
  
  clReleaseMemObject(fMem);
  clReleaseMemObject(FMem);
  clReleaseMemObject(gMem);
  clReleaseKernel(dftKernel);
  clReleaseKernel(idftKernel);
  clReleaseProgram(program);
  clReleaseCommandQueue(queue);
  clReleaseContext(context);
  
  free(kernelSource);
  free(f);
  free(F);
  free(g);
  
  tprintf(&st, "%d\n", N);
  
  return 0;
}