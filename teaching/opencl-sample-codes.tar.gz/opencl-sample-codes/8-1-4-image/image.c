#include <stdio.h>
#include <string.h>

#include <error.h>
#include <kernelio.h>
#include <stopper.h>
#include <openclinit.h>
#include <pngio.h>

#include <CL/opencl.h>

int main(int argc, char** argv)
{
  cl_int err;
  cl_context context;
  cl_command_queue queue;
  cl_mem imgInMem, imgOutMem;
  cl_event event;
  cl_program program;
  cl_kernel kernel;
  cl_uint numDevices;
  cl_device_id devices[MAX_DEVICES];
  char* kernelSource;
  size_t kernelLength;
  unsigned char *imageIn, *imageOut;
  unsigned int rows, columns, imn, i, n;
  cl_image_format cif;
  cl_image_desc cid;
  size_t origin[3]= {0, 0, 0};
  size_t region[3]= {0, 0, 0};
  
  createContextAndCommandQueue(&context, &queue, devices, &numDevices);
  
  readPNG(argv[1], &imageIn, &rows, &columns);
  imageOut= (unsigned char*)malloc(sizeof(unsigned char)*rows*columns*4);
  
  cif.image_channel_order= CL_RGBA;
  cif.image_channel_data_type= CL_UNSIGNED_INT8;
  
  cid.image_type= CL_MEM_OBJECT_IMAGE2D;
  cid.image_width= columns;
  cid.image_height= rows;
  cid.image_depth= 1;
  cid.image_array_size= 0;
  cid.image_row_pitch= 0;
  cid.image_slice_pitch= 0;
  cid.num_mip_levels= 0;
  cid.num_samples= 0;
  cid.buffer= NULL;
  
  imgInMem= clCreateImage(context,               //context object
                          CL_MEM_USE_HOST_PTR,   //flags
                          &cif,                  //image format
                          &cid,                  //image descriptor
                          imageIn,               //pointer to data
                          &err);                 //pointer to error
  ERROR(err, "clCreateImage")

  region[0]= columns;
  region[1]= rows;
  region[2]= 1;  
  err= clEnqueueWriteImage(queue,                //command queue
                           imgInMem,             //memory object
                           CL_TRUE,              //blocking write
                           origin,               //origin of write
                           region,               //size of region to write
                           0,                    //row pitch
                           0,                    //slice pitch
                           imageIn,              //pointer to data              
                           0,                    //number of events in array
                           NULL,                 //array of events
                           NULL);                //pointer to output event
  ERROR(err, "clEnqueueWriteImage")
  
  err= clEnqueueReadImage(queue,                 //command queue
                          imgInMem,              //memory object
                          CL_TRUE,               //blocking read
                          origin,                //origin of write
                          region,                //size of region to write
                          0,                     //row pitch
                          0,                     //slice pitch
                          imageOut,               //pointer to allocated area
                          0,                     //number of events in event array  
                          NULL,                  //array of events 
                          NULL);                 //pointer to output event
  ERROR(err, "clEnqueueReadImage")
  
  writePNG(argv[2], imageOut, rows, columns);
  
  clReleaseMemObject(imgInMem);
  clReleaseCommandQueue(queue);
  clReleaseContext(context);
  
  free(imageIn);
  free(imageOut);
  
  return 0;
}