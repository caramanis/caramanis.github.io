#include <stdio.h>
#include <string.h>
#include <error.h>
#include <kernelio.h>
#include <stopper.h>
#include <CL/opencl.h>

#define MAX_DEVICES 2
#define MAX_PLATFORMS 2

void printSM(float* m, int n)
{
  int i, j;
  for ( i= 0; i < n; ++i )
  {
    for ( j= 0; j < n; ++j )
      printf("%.0f ", m[i*n + j]);
    printf("\n");
  }
  printf("\n");
}

int main(int argc, char** argv)
{
  cl_int err;
  cl_context context;
  cl_command_queue queue;
  cl_mem matrixA, matrixB, matrixC;
  int i, n;
  cl_event event;
  cl_uint numDevices;
  cl_device_id devices[MAX_DEVICES];
  cl_uint numPlatforms;
  cl_platform_id platforms[MAX_PLATFORMS];
  cl_context_properties properties[MAX_PLATFORMS*2]= {0};
  size_t size;
  cl_program program;
  cl_kernel kernel;
  char* kernelSource;
  size_t kernelLength;
  float *A, *B, *C;
  size_t global_work_size[2];
  
  n= atoi(argv[1]);
  global_work_size[0]= global_work_size[1]= n;
  A= (float*)malloc(sizeof(float)*n*n);
  B= (float*)malloc(sizeof(float)*n*n);
  C= (float*)malloc(sizeof(float)*n*n);  
  
  for ( i= 0; i < n*n; ++i )
  {
    A[i]= rand()%10;
    B[i]= rand()%10;
  }

  err= clGetPlatformIDs(MAX_PLATFORMS, platforms, &numPlatforms);
  ERROR(err, "clGetPlatformIDs")  

  for ( i= 0; i < numPlatforms; ++i )
  {
    properties[i*2]= (cl_context_properties)CL_CONTEXT_PLATFORM;
    properties[i*2 + 1]= (cl_context_properties)(platforms[i]);
  }
  properties[i*2]= 0;
  
  context= clCreateContextFromType(properties, CL_DEVICE_TYPE_ALL, NULL, NULL, &err);
  ERROR(err, "clCreateContextFromType")
  
  err= clGetContextInfo(context, CL_CONTEXT_DEVICES, MAX_DEVICES*sizeof(cl_device_id), devices, &size);
  ERROR(err, "clGetContextInfo")
  err= clGetContextInfo(context, CL_CONTEXT_NUM_DEVICES, sizeof(cl_uint), &numDevices, &size);
  ERROR(err, "clGetContextInfo")
  
  queue= clCreateCommandQueue(context, devices[0], 0, &err);
  ERROR(err, "clCreateCommandQueue")
  
  matrixA= clCreateBuffer(context, 0, n*n*sizeof(float), NULL, &err);
  ERROR(err, "clCreateBuffer")
  matrixB= clCreateBuffer(context, 0, n*n*sizeof(float), NULL, &err);
  ERROR(err, "clCreateBuffer")
  matrixC= clCreateBuffer(context, 0, n*n*sizeof(float), NULL, &err);
  ERROR(err, "clCreateBuffer")
  
  readSourceProgram("matrixMultiplication.k", &kernelSource, &kernelLength);
  program= clCreateProgramWithSource( context, 1, (const char**)&kernelSource, NULL, &err);
  ERROR(err, "clCreateProgramWithSource")
    
  err= clBuildProgram(program, numDevices, devices, NULL, NULL, NULL);
  ERROR(err, "clBuildProgram")
  
  kernel= clCreateKernel(program, "matrixMultiplication", &err);
  ERROR(err, "clCreateKernel")

  err= clEnqueueWriteBuffer(queue, matrixA, 1, 0, sizeof(float)*n*n, A, 0, NULL, NULL);
  ERROR(err, "clEnqueueWriteBuffer")
  err= clEnqueueWriteBuffer(queue, matrixB, 1, 0, sizeof(float)*n*n, B, 0, NULL, NULL);
  ERROR(err, "clEnqueueWriteBuffer")
  
  err= clSetKernelArg(kernel, 0, sizeof(cl_mem), &matrixA);
  ERROR(err, "clSetKernelArg")
  err= clSetKernelArg(kernel, 1, sizeof(cl_mem), &matrixB);
  ERROR(err, "clSetKernelArg")
  err= clSetKernelArg(kernel, 2, sizeof(cl_mem), &matrixC);
  ERROR(err, "clSetKernelArg")
  
  stopper st;
  startS(&st);
  err= clEnqueueNDRangeKernel(queue,               //command queue
                              kernel,              //kernel
                              2,                   //dimensions
                              NULL,                //global index offset
                              global_work_size,    //global work size
                              NULL,                //local work size
                              0,                   //number of events
                              NULL,                //array of events
                              &event);               //output event
  ERROR(err, "clEnqueueNDRangeKernel")
  clWaitForEvents(1, &event);
  stopS(&st);

  err= clEnqueueReadBuffer(queue, matrixC, 1, 0, sizeof(float)*n*n, C, 0, NULL, NULL);
  ERROR(err, "clEnqueueReadBuffer")
  
/*  printSM(A, n);
  printSM(B, n);
  printSM(C, n);*/
  
  clReleaseMemObject(matrixA);
  clReleaseMemObject(matrixB);
  clReleaseMemObject(matrixC);
  clReleaseKernel(kernel);
  clReleaseProgram(program);
  clReleaseCommandQueue(queue);
  clReleaseContext(context);
  
  free(kernelSource);
  free(A);
  free(B);
  free(C);
  
  tprintf(&st, "%d\n", n);
  
  return 0;
}