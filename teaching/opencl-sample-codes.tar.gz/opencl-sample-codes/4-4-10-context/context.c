#include <stdio.h>
#include <error.h>
#include <CL/opencl.h>

#define MAX_PLATFORMS 10
#define MAX_DEVICES 10
#define MAX_STRING_SIZE 1000

void notify(const char* errinfo, const void* private_info, size_t cb, void* user_data)
{
  fprintf(*(FILE**)(user_data), "CALLBACK notification: %s\n", errinfo);
}

void contextInfo(cl_context* context)
{
  cl_uint numDevices;
  cl_device_id devices[MAX_DEVICES]= {0};
  char name[MAX_STRING_SIZE];
  size_t size;
  int i;
  cl_int err;
  
  err= clGetContextInfo(*context,               //context object
                        CL_CONTEXT_NUM_DEVICES, //name of property
                        sizeof(cl_uint),        //size of property
                        &numDevices,            //pointer of property
                        &size);                 //pointer of size variable
  ERROR(err, "clGetContextInfo");
  
  err= clGetContextInfo(*context,                          //context object
                        CL_CONTEXT_DEVICES,                //name of property
                        MAX_DEVICES*sizeof(cl_device_id),  //size of property
                        &devices,                          //pointer of property
                        &size);                            //pointer of size variable
  ERROR(err, "clGetContextInfo");
  
  printf("%d devices are mapped to context %p:\n", (int)numDevices, *context);
  for ( i= 0; i < numDevices; ++i )
  {
    err= clGetDeviceInfo(devices[i], CL_DEVICE_NAME, MAX_STRING_SIZE, &name, &size);
    ERROR(err, "clGetDeviceInfo");
    printf("\t %s\n", name);
  }
}

int main(int argc, char** argv)
{
  cl_int err;
  cl_uint numPlatforms;
  cl_platform_id platforms[MAX_PLATFORMS];
  cl_uint numDevices;
  cl_device_id devices[MAX_DEVICES];
  char pString[MAX_STRING_SIZE];
  cl_device_type pcdt;
  cl_uint puint;
  size_t psize;
  cl_ulong pulong;
  cl_bool pbool;
  cl_context context;
  cl_context_properties properties[MAX_PLATFORMS*2]= {0};
  size_t size;
  int i, j;
  size_t t[3];
  int selected_platform, selected_device;

  err= clGetPlatformIDs(MAX_PLATFORMS, platforms, &numPlatforms);
  ERROR(err, "clGetPlatformIDs");

  for ( i= 0; i < numPlatforms; ++i )
  {
    printf("[%d]\t", i);
    err= clGetPlatformInfo(platforms[i], CL_PLATFORM_NAME, MAX_STRING_SIZE, &pString, &size);
    ERROR(err, "clGetPlatformInfo");
    printf("%s\t", pString);
    err= clGetPlatformInfo(platforms[i], CL_PLATFORM_VENDOR, MAX_STRING_SIZE, &pString, &size);
    ERROR(err, "clGetPlatformInfo");
    printf("%s\t", pString);
    err= clGetPlatformInfo(platforms[i], CL_PLATFORM_VERSION, MAX_STRING_SIZE, &pString, &size);
    ERROR(err, "clGetPlatformInfo");
    printf("%s\n", pString);
  }
  printf("Please choose a platform! (0-%d)\n", numPlatforms-1);  
  scanf("%d", &selected_platform);
  
  err= clGetDeviceIDs(platforms[selected_platform], CL_DEVICE_TYPE_ALL, MAX_DEVICES, devices, &numDevices);
  ERROR(err, "clGetDeviceIDs");
  
  for ( j= 0; j < numDevices; ++j )
  {
    printf("[%d]\t", j);
    err= clGetDeviceInfo(devices[j], CL_DEVICE_VENDOR, MAX_STRING_SIZE, &pString, &size);
    ERROR(err, "clGetDeviceInfo");
    printf("%s\t", pString);
    
    err= clGetDeviceInfo(devices[j], CL_DEVICE_NAME, MAX_STRING_SIZE, &pString, &size);
    ERROR(err, "clGetDeviceInfo");
    printf("%s\t", pString);
      
    err= clGetDeviceInfo(devices[j], CL_DEVICE_VERSION, MAX_STRING_SIZE, &pString, &size);
    ERROR(err, "clGetDeviceInfo");
    printf("%s\t", pString);
    
    err= clGetDeviceInfo(devices[j], CL_DRIVER_VERSION, MAX_STRING_SIZE, &pString, &size);
    ERROR(err, "clGetDeviceInfo");
    printf("%s\t", pString);
    
    err= clGetDeviceInfo(devices[j], CL_DEVICE_OPENCL_C_VERSION, MAX_STRING_SIZE, &pString, &size);
    ERROR(err, "clGetDeviceInfo");
    printf("%s\n", pString);
  }
  printf("Please choose a device! (0-%d)\n", numDevices-1);
  scanf("%d", &selected_device);
  
  properties[0]= (cl_context_properties)CL_CONTEXT_PLATFORM;
  properties[1]= (cl_context_properties)platforms[selected_platform];
  properties[2]= 0;

  printf("Create context with platform property\n");
  context= clCreateContext(properties,          //context properties
                           1,                   //number of devices
                           devices,             //array of devices
                           notify,              //notify function
                           &stderr,             //user_data of notify
                           &err);               //error code pointer
  ERROR(err, "clCreateContext");
  
  contextInfo(&context);
  
  clReleaseContext(context);
  ERROR(err, "clReleaseContext");
  printf("\n");

  printf("Create context from all type of device\n");
  context= clCreateContextFromType(properties,          //context properties
                                   CL_DEVICE_TYPE_ALL,  //type of devices
                                   notify,              //notify function
                                   &stderr,             //user_data of notify
                                   &err);               //error code pointer
  ERROR(err, "clCreateContextFromType");
  
  contextInfo(&context);
  
  clReleaseContext(context);
  ERROR(err, "clReleaseContext");
  printf("\n");
  
  printf("Create context from GPU devices\n");
  context= clCreateContextFromType(NULL,                //context properties
                                   CL_DEVICE_TYPE_GPU,  //type of devices
                                   notify,              //notify function
                                   &stderr,             //user_data of notify
                                   &err);               //error code pointer
  ERROR(err, "clCreateContextFromType");
  
  contextInfo(&context);
  err= clReleaseContext(context);
  ERROR(err, "clReleaseContext");
  
  return 0;
}