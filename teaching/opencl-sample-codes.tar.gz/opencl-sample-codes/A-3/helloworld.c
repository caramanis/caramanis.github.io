#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <CL/opencl.h>

#define ARRAY_SIZE 40
#define MAX_DEVICES 2
#define MAX_PLATFORMS 2
#define MAX_SOURCE_LENGTH 2000

#define ERROR(err, prefix) if ( err != CL_SUCCESS ) printErrorString(stderr, err, prefix);

int printErrorString(FILE* o, int err, const char* p)
{
  switch(err)
  {
    case CL_SUCCESS: fprintf(o, "%s: Success.\n", p); break;
    case CL_DEVICE_NOT_FOUND: fprintf(o, "%s: Device not found.\n", p); break;
    case CL_DEVICE_NOT_AVAILABLE: fprintf(o, "%s: Device not available.\n", p); break;
    case CL_COMPILER_NOT_AVAILABLE: fprintf(o, "%s: Compiler not available.\n", p); break;
    case CL_MEM_OBJECT_ALLOCATION_FAILURE: fprintf(o, "%s: Mem. obj. app. fail.\n", p); break;
    case CL_OUT_OF_RESOURCES: fprintf(o, "%s: Out of resources.\n", p); break;
    case CL_OUT_OF_HOST_MEMORY: fprintf(o, "%s: Out of host memory.\n", p); break;
    case CL_BUILD_PROGRAM_FAILURE: fprintf(o, "%s: Program build failure.\n", p); break;
    case CL_INVALID_VALUE: fprintf(o, "%s: Invalid value.\n", p); break;
    case CL_INVALID_DEVICE_TYPE: fprintf(o, "%s: Invalid device type.\n", p); break;
    case CL_INVALID_PLATFORM: fprintf(o, "%s: Invalid platform.\n", p); break;
    case CL_INVALID_DEVICE: fprintf(o, "%s: Invalid device.\n", p); break;
    case CL_INVALID_CONTEXT: fprintf(o, "%s: Invalid context.\n", p); break;
    case CL_INVALID_QUEUE_PROPERTIES: fprintf(o, "%s: Invalid queue properties.\n", p); break;
    case CL_INVALID_COMMAND_QUEUE: fprintf(o, "%s: Invalid command queue.\n", p); break;
    case CL_INVALID_HOST_PTR: fprintf(o, "%s: Invalid host pointer.\n", p); break;
    case CL_INVALID_MEM_OBJECT: fprintf(o, "%s: Invalid memory object.\n", p); break;
    case CL_INVALID_BINARY: fprintf(o, "%s: Invalid binary.\n", p); break;
    case CL_INVALID_BUILD_OPTIONS: fprintf(o, "%s: Invalid build options.\n", p); break;
    case CL_INVALID_PROGRAM: fprintf(o, "%s: Invalid program.\n", p); break;
    case CL_INVALID_PROGRAM_EXECUTABLE: fprintf(o, "%s: Invalid program exec.\n", p); break;
    case CL_INVALID_KERNEL_NAME: fprintf(o, "%s: Invalid kernel name.\n", p); break;
    case CL_INVALID_KERNEL_DEFINITION: fprintf(o, "%s: Invalid kernel def.\n", p); break;
    case CL_INVALID_KERNEL: fprintf(o, "%s: Invalid kernel.\n", p); break;
    case CL_INVALID_ARG_INDEX: fprintf(o, "%s: Invalid argument index.\n", p); break;
    case CL_INVALID_ARG_VALUE: fprintf(o, "%s: Invalid argument value.\n", p); break;
    case CL_INVALID_ARG_SIZE: fprintf(o, "%s: Invalid argument size.\n", p); break;
    case CL_INVALID_KERNEL_ARGS: fprintf(o, "%s: Invalid kernel arguments.\n", p); break;
    case CL_INVALID_WORK_DIMENSION: fprintf(o, "%s: Invalid work dimension.\n", p); break;
    case CL_INVALID_WORK_GROUP_SIZE: fprintf(o, "%s: Invalid work group size.\n", p); break;
    case CL_INVALID_WORK_ITEM_SIZE: fprintf(o, "%s: Invalid work item size.\n", p); break;
    case CL_INVALID_GLOBAL_OFFSET: fprintf(o, "%s: Invalid global offset.\n", p); break;
    case CL_INVALID_EVENT_WAIT_LIST: fprintf(o, "%s: Invalid event wait list.\n", p); break;
    case CL_INVALID_OPERATION: fprintf(o, "%s: Invalid operation.\n", p); break;
    default: fprintf(o, "%s: Unknown error.\n", p); break;
  }
  fflush(o);
}


void readSourceProgram(char* filename, char** source, size_t* length)
{
  FILE* input= fopen(filename, "rt");
  int maxLength= MAX_SOURCE_LENGTH;
  *length= 0;
  *source= (char*)malloc(sizeof(char)*MAX_SOURCE_LENGTH);
  while ( !feof(input) )
  {
    fgets(*source + *length, maxLength, input);
    *length= strlen(*source);
    maxLength-= *length;
  }
  *source= (char*)realloc(*source, sizeof(char)*strlen(*source));
  fclose(input);
}

int main(int argc, char** argv)
{
  cl_int err;
  cl_context context;
  cl_command_queue queue;
  cl_mem memobj;
  char output[ARRAY_SIZE];
  cl_uint numDevices;
  cl_device_id devices[MAX_DEVICES];
  cl_uint numPlatforms;
  cl_platform_id platforms[MAX_PLATFORMS];
  cl_context_properties properties[MAX_PLATFORMS*2]= {0};
  size_t size, global_work_size;
  cl_program program;
  cl_kernel kernel;
  int i;
  char* kernelSource;
  size_t kernelLength;
  
  readSourceProgram("helloWorld.k", &kernelSource, &kernelLength);

  /** Platform, eszkoz, kornyezet, parancssor lekerdezese, letrehozasa. */
  err= clGetPlatformIDs(MAX_PLATFORMS, platforms, &numPlatforms);
  ERROR(err, "clGetPlatformIDs");
  
  for ( i= 0; i < numPlatforms; ++i )
  {
    properties[i*2]= (cl_context_properties)CL_CONTEXT_PLATFORM;
    properties[i*2 + 1]= (cl_context_properties)(platforms[i]);
  }
  
  context= clCreateContextFromType(properties, CL_DEVICE_TYPE_GPU, NULL, NULL, &err);
  ERROR(err, "clCreateContextFromType");
  
  err= clGetContextInfo(context, CL_CONTEXT_DEVICES, MAX_DEVICES*sizeof(cl_device_id), devices, &size);
  ERROR(err, "clGetContextInfo");
  
  err= clGetContextInfo(context, CL_CONTEXT_NUM_DEVICES, sizeof(cl_uint), &numDevices, &size);
  ERROR(err, "clGetContextInfo");
  
  queue= clCreateCommandQueue(context, devices[0], 0, &err);
  ERROR(err, "clCreateCommandQueue");
  
  /** Memoriaobjektum letrehozasa. */
  memobj= clCreateBuffer(context, 0, ARRAY_SIZE * sizeof(char), NULL, &err);
  ERROR(err, "clCreateBuffer");
  
  /** Kernel-kod forditasa, kernel-objektum letrehozasa. */
  program= clCreateProgramWithSource( context, 1, (const char**)&kernelSource, NULL, &err);
  ERROR(err, "clCreateProgramWithSource");
    
  err= clBuildProgram(program, numDevices, devices, NULL, NULL, NULL);
  ERROR(err, "clBuildProgram");
  
  kernel= clCreateKernel(program, "helloWorld", &err);
  ERROR(err, "clCreateKernel");
 
  /** Kernel parametereinek beallitasa. */
  err= clSetKernelArg(kernel, 0, sizeof(memobj), &memobj);
  ERROR(err, "clSetKernelArg");
  
  /** Kernel vegrehajtasok utemezese, eredmeny olvasasa. */
  global_work_size= ARRAY_SIZE;
  err= clEnqueueNDRangeKernel(queue, kernel, 1, NULL, &global_work_size, NULL, 0, NULL, NULL);
  ERROR(err, "clEnqueueNDRangeKernel");
  
  clFinish(queue);
  ERROR(err, "clFinish");
  
  /** Eredmenyek olvasasa es kiirasa. */
  err= clEnqueueReadBuffer(queue, memobj, 1, 0, sizeof(char)*ARRAY_SIZE, output, 0, NULL, NULL);
  ERROR(err, "clEnqueueReadBuffer");
  
  printf("%s\n", output);
  
  /** Lefoglalt eroforrasok felszabaditasa. */
  clReleaseMemObject(memobj);
  ERROR(err, "clReleaseMemObject");
  clReleaseKernel(kernel);
  ERROR(err, "clReleaseKernel");
  clReleaseProgram(program);
  ERROR(err, "clReleaseProgram");
  clReleaseCommandQueue(queue);
  ERROR(err, "clReleaseQueue");
  clReleaseContext(context);
  ERROR(err, "clReleaseContext");
  
  return 0;
}