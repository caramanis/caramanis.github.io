#include <stdio.h>
#include <error.h>
#include <CL/opencl.h>

#define MAX_PLATFORMS 10
#define MAX_DEVICES 10
#define MAX_STRING_SIZE 1000

int main(int argc, char** argv)
{
  cl_int err;
  cl_uint numPlatforms;
  cl_platform_id platforms[MAX_PLATFORMS];
  cl_uint numDevices;
  cl_device_id devices[MAX_DEVICES];
  char pString[MAX_STRING_SIZE];
  cl_device_type pcdt;
  cl_uint puint;
  size_t psize;
  cl_ulong pulong;
  cl_bool pbool;
  size_t size, t[3];
  int i, j;

  err= clGetPlatformIDs(MAX_PLATFORMS, platforms, &numPlatforms);
  ERROR(err, "clGetPlatformIDs");

  printf("Number of platforms: %d\n", numPlatforms);
  for ( i= 0; i < numPlatforms; ++i )
  {
    err= clGetPlatformInfo(platforms[i], CL_PLATFORM_NAME, MAX_STRING_SIZE, pString, &size);
    ERROR(err, "clGetPlatformInfo");
    printf("Platform name: %s\n", pString);
    
    err= clGetDeviceIDs(platforms[i],        //platform id
                        CL_DEVICE_TYPE_ALL,  //device type
                        MAX_DEVICES,         //size of array devices
                        devices,             //array of device ids
                        &numDevices);        //number of devices
    ERROR(err, "clGetDeviceIDs");
    
    printf("Number of devices in platform %d: %d\n", platforms[i], numDevices);
    for ( j= 0; j < numDevices; ++j )
    {
      err= clGetDeviceInfo(devices[j],                            //device id
                           CL_DEVICE_MAX_COMPUTE_UNITS,           //property
                           sizeof(cl_uint),                       //max size of property
                           &puint,                                //address of property
                           &size);                                //number of returned bytes
      ERROR(err, "clGetDeviceInfo");
      printf("\t Device max compute units: %d\n", puint);

      err = clGetDeviceInfo(devices[j],                           //device id
                            CL_DEVICE_MAX_WORK_ITEM_DIMENSIONS,   //property
                            sizeof(cl_uint),                      //max size of property
                            &puint,                               //address of property
                            &size);                               //number of returned bytes
      ERROR(err, "clGetDeviceInfo");
      printf("\t Device max work item dimensions: %d\n", puint);

      err= clGetDeviceInfo(devices[j],                            //device id
                           CL_DEVICE_MAX_WORK_ITEM_SIZES,         //property
                           sizeof(size_t)*3,                      //max size of property
                           &t,                                    //address of property
                           &size);                                //number of returned bytes
      ERROR(err, "clGetDeviceInfo");
      printf("\t Device max work item sizes: %d %d %d\n", t[0], t[1], t[2]);

      err= clGetDeviceInfo(devices[j],                            //device id
                           CL_DEVICE_MAX_WORK_GROUP_SIZE,         //property
                           sizeof(psize),                         //max size of property
                           &psize,                                //address of property
                           &size);                                //number of returned bytes
      ERROR(err, "clGetDeviceInfo");
      printf("\t Device max work group size: %d\n", psize);
      
      err= clGetDeviceInfo(devices[j],                            //device id
                           CL_DEVICE_GLOBAL_MEM_SIZE,             //property
                           sizeof(cl_ulong),                      //max size of property
                           &pulong,                               //address of property
                           &size);                                //number of returned bytes
      ERROR(err, "clGetDeviceInfo");
      printf("\t Device max global mem size: %d\n", pulong);
     
      err= clGetDeviceInfo(devices[j],                            //device id
                           CL_DEVICE_MAX_CONSTANT_BUFFER_SIZE,    //property
                           sizeof(cl_ulong),                      //max size of property
                           &pulong,                               //address of property
                           &size);                                //number of returned bytes
      ERROR(err, "clGetDeviceInfo");
      printf("\t Device max constant buffer size: %d\n", pulong);
      
      err= clGetDeviceInfo(devices[j],                            //device id
                           CL_DEVICE_LOCAL_MEM_SIZE,              //property
                           sizeof(cl_ulong),                      //max size of property
                           &pulong,                               //address of property
                           &size);                                //number of returned bytes
      ERROR(err, "clGetDeviceInfo");
      printf("\t Device max local mem size: %d\n", pulong);
      
      err= clGetDeviceInfo(devices[j],                            //device id
                           CL_DEVICE_PRINTF_BUFFER_SIZE,          //property
                           sizeof(size_t),                        //max size of property
                           &psize,                                //address of property
                           &size);                                //number of returned bytes
      ERROR(err, "clGetDeviceInfo");
      printf("\t Device printf buffer size: %d\n", psize);
      
      err= clGetDeviceInfo(devices[j],                            //device id
                           CL_DEVICE_LINKER_AVAILABLE,            //property
                           sizeof(cl_bool),                       //max size of property
                           &pbool,                                //address of property
                           &size);                                //number of returned bytes
      ERROR(err, "clGetDeviceInfo");
      printf("\t Device linker available: %d\n", pbool);
      
      err= clGetDeviceInfo(devices[j],                            //device id
                           CL_DEVICE_NAME,                        //property
                           MAX_STRING_SIZE,                       //max size of property
                           &pString,                              //address of property
                           &size);                                //number of returned bytes
      ERROR(err, "clGetDeviceInfo");
      printf("\t Device name: %s\n", pString);
      
      err= clGetDeviceInfo(devices[j],                            //device id
                           CL_DEVICE_VENDOR,                      //property
                           MAX_STRING_SIZE,                       //max size of property
                           &pString,                              //address of property
                           &size);                                //number of returned bytes
      ERROR(err, "clGetDeviceInfo");
      printf("\t Device vendor: %s\n", pString);
      
      err= clGetDeviceInfo(devices[j],                            //device id
                           CL_DEVICE_VERSION,                     //property
                           MAX_STRING_SIZE,                       //max size of property
                           &pString,                              //address of property
                           &size);                                //number of returned bytes
      ERROR(err, "clGetDeviceInfo");
      printf("\t Device version: %s\n", pString);
      
      err= clGetDeviceInfo(devices[j],                            //device id
                           CL_DRIVER_VERSION,                     //property
                           MAX_STRING_SIZE,                       //max size of property
                           &pString,                              //address of property
                           &size);                                //number of returned bytes
      ERROR(err, "clGetDeviceInfo");
      printf("\t Driver version: %s\n", pString);
      
      err= clGetDeviceInfo(devices[j],                            //device id
                           CL_DEVICE_OPENCL_C_VERSION,            //property
                           MAX_STRING_SIZE,                       //max size of property
                           &pString,                              //address of property
                           &size);                                //number of returned bytes
      ERROR(err, "clGetDeviceInfo");
      printf("\t Device OpenCL C version: %s\n", pString);
    }
  }
  
  return 0;
}