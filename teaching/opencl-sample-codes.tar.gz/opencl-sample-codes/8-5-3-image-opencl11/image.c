#include <stdio.h>
#include <string.h>

#include <error.h>
#include <kernelio.h>
#include <stopper.h>
#include <openclinit.h>
#include <pngio.h>

#include <CL/opencl.h>

int main(int argc, char** argv)
{
  cl_int err;
  cl_context context;
  cl_command_queue queue;
  cl_mem imgInMem, imgOutMem, weightsMem, posMem;
  cl_event event;
  cl_program program;
  cl_kernel kernel;
  cl_uint numDevices;
  cl_device_id devices[MAX_DEVICES];
  char* kernelSource;
  size_t kernelLength;
  size_t global_work_size[2];
  unsigned char *imageIn, *imageOut;
  int* pos;
  unsigned int rows, columns, imn, i, n;
  cl_image_format cif;
  cl_image_desc cid;
  size_t origin[3]= {0, 0, 0};
  size_t region[3]= {0, 0, 0};
  
  createContextAndCommandQueue(&context, &queue, devices, &numDevices);
  
  readPNG(argv[1], &imageIn, &rows, &columns);
  imageOut= (unsigned char*)malloc(sizeof(unsigned char)*4*rows*columns);
  
  cif.image_channel_order= CL_RGBA;
  cif.image_channel_data_type= CL_UNSIGNED_INT8;
  
  imgInMem= clCreateImage2D(context,                //context object
                            0,                      //default flags
                            &cif,                   //image format
                            columns,                //image width
                            rows,                   //image height
                            0,                      //row pitch
                            NULL,                   //host pointer
                            &err);                  //pointer to error
  ERROR(err, "clCreateImage2D")

  region[0]= columns;
  region[1]= rows;
  region[2]= 1;  
  err= clEnqueueWriteImage(queue,                   //command queue object
                           imgInMem,                //object to write
                           CL_TRUE,                 //blocking write
                           origin,                  //origin of write
                           region,                  //size of region to write
                           0,                       //row pitch
                           0,                       //slice pitch
                           imageIn,                 //data to write
                           0,                       //number of events in the array
                           NULL,                    //array of events
                           NULL);                   //output event
  ERROR(err, "clEnqueueWriteImage")
  
  err= clEnqueueReadImage(queue,                    //command queue object
                          imgInMem,                 //object to read
                          CL_TRUE,                  //blocking read
                          origin,                   //origin of read
                          region,                   //size of region to read
                          0,                        //row pitch
                          0,                        //slice pitch
                          imageOut,                 //pointer to host region
                          0,                        //number of events in the array
                          NULL,                     //array of events
                          NULL);                    //output event
  ERROR(err, "clEnqueueReadImage")
  
  writePNG(argv[2], imageOut, rows, columns);
  
  clReleaseMemObject(imgInMem);
  clReleaseCommandQueue(queue);
  clReleaseContext(context);
  
  free(imageIn);
  free(imageOut);
  
  return 0;
}