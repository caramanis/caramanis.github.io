#include <stdio.h>
#include <string.h>

#include <error.h>
#include <kernelio.h>
#include <stopper.h>
#include <filter.h>
#include <openclinit.h>

#include <CL/opencl.h>

int main(int argc, char** argv)
{
  cl_int err;
  cl_context context;
  cl_command_queue queue;
  cl_mem imgInMem, imgOutMem, weightsMem, posMem;
  cl_event event;
  cl_program program;
  cl_kernel kernel;
  cl_uint numDevices;
  cl_device_id devices[MAX_DEVICES];
  char* kernelSource;
  size_t kernelLength;
  size_t global_work_size[2];
  float *imageIn, *imageOut, *weights;
  int* pos;
  unsigned int rows, columns, imn, i, n;
  
  createContextAndCommandQueue(&context, &queue, devices, &numDevices);
  
  readPGM(argv[1], &imageIn, &rows, &columns);
  generateGaussianFilter(atof(argv[2]), columns, &weights, &pos, &n);
  imageOut= (float*)malloc(sizeof(float)*rows*columns);
  
  imgInMem= clCreateBuffer(context, 0, rows*columns*sizeof(float), NULL, &err);
  ERROR(err, "clCreateBuffer")
  imgOutMem= clCreateBuffer(context, 0, rows*columns*sizeof(float), NULL, &err);
  ERROR(err, "clCreateBuffer")
  weightsMem= clCreateBuffer(context, 0, n*sizeof(float), NULL, &err);
  ERROR(err, "clCreateBuffer")
  posMem= clCreateBuffer(context, 0, n*sizeof(int), NULL, &err);
  ERROR(err, "clCreateBuffer")
  
  readSourceProgram("filter.k", &kernelSource, &kernelLength);
  program= clCreateProgramWithSource( context, 1, &kernelSource, NULL, &err);
  ERROR(err, "clCreateProgramWithSource")
    
  err= clBuildProgram(program, numDevices, devices, NULL, NULL, NULL);
  ERROR(err, "clBuildProgram")
  
  kernel= clCreateKernel(program, "filter", &err);
  ERROR(err, "clCreateKernel")

  err= clEnqueueWriteBuffer(queue, imgInMem, 1, 0, sizeof(float)*rows*columns, imageIn, 0, NULL, NULL);
  ERROR(err, "clEnqueueWriteBuffer")
  err= clEnqueueWriteBuffer(queue, weightsMem, 1, 0, sizeof(float)*n, weights, 0, NULL, NULL);
  ERROR(err, "clEnqueueWriteBuffer")
  err= clEnqueueWriteBuffer(queue, posMem, 1, 0, sizeof(int)*n, pos, 0, NULL, NULL);
  ERROR(err, "clEnqueueWriteBuffer")
  
  imn= rows*columns;
  err= clSetKernelArg(kernel, 0, sizeof(cl_mem), &imgInMem);
  ERROR(err, "clSetKernelArg")
  err= clSetKernelArg(kernel, 1, sizeof(unsigned int), &imn);
  ERROR(err, "clSetKernelArg")
  err= clSetKernelArg(kernel, 2, sizeof(cl_mem), &weightsMem);
  ERROR(err, "clSetKernelArg")
  err= clSetKernelArg(kernel, 3, sizeof(cl_mem), &posMem);
  ERROR(err, "clSetKernelArg")
  err= clSetKernelArg(kernel, 4, sizeof(unsigned int), &n);
  ERROR(err, "clSetKernelArg")
  err= clSetKernelArg(kernel, 5, sizeof(cl_mem), &imgOutMem);
  ERROR(err, "clSetKernelArg")

  global_work_size[0]= rows*columns;
  //global_work_size[1]= columns;

  stopper st;
  startS(&st);
  err= clEnqueueNDRangeKernel(queue, kernel, 1, NULL, global_work_size, NULL, 0, NULL, &event);
  ERROR(err, "clEnqueueNDRangeKernel")
  clWaitForEvents(1, &event);
  stopS(&st);

  err= clEnqueueReadBuffer(queue, imgOutMem, 1, 0, sizeof(float)*rows*columns, imageOut, 0, NULL, NULL);
  ERROR(err, "clEnqueueReadBuffer")
  
  writePGM(argv[3], imageOut, rows, columns);
  
  clReleaseMemObject(imgInMem);
  clReleaseMemObject(imgOutMem);
  clReleaseMemObject(weightsMem);
  clReleaseMemObject(posMem);
  clReleaseKernel(kernel);
  clReleaseProgram(program);
  clReleaseCommandQueue(queue);
  clReleaseContext(context);
  
  free(kernelSource);
  free(imageIn);
  free(imageOut);
  free(weights);
  free(pos);
  
  tprintf(&st, "%f\n", atof(argv[2]));
  
  return 0;
}