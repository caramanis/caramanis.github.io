#ifndef __ERROR_H__
#define __ERROR_H__

#include <stdio.h>
#include <CL/opencl.h>

#define ERROR(a,b) {if(a != CL_SUCCESS) errorMessage(stderr, a, b);}

void notify(const char* errinfo, const void* private_info, size_t cb, void* user_data);

void errorMessage(FILE* f, int code, const char* prefix);

#endif