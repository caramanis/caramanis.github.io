#include <stdio.h>
#include <error.h>
#include <CL/opencl.h>

#define ARRAY_SIZE 10
#define MAX_DEVICES 2
#define MAX_PLATFORMS 2

int main(int argc, char** argv)
{
  cl_int err;
  cl_context context;
  cl_command_queue queue;
  cl_mem memobj;
  cl_event event;
  cl_uint numPlatforms;
  cl_platform_id platforms[MAX_PLATFORMS];
  cl_uint numDevices;
  cl_device_id devices[MAX_DEVICES];
  cl_context_properties properties[3]= {0};
  size_t size;
  
  int input[ARRAY_SIZE];
  int output[ARRAY_SIZE/2];
  int i;
  int* p, *p2;
  
  for ( i= 0; i < ARRAY_SIZE; ++i )
    input[i]= i;

  err= clGetPlatformIDs(MAX_PLATFORMS, platforms, &numPlatforms);
  ERROR(err, "clGetPlatformIDs");
  
  properties[0]= (cl_context_properties)CL_CONTEXT_PLATFORM;
  properties[1]= (cl_context_properties)(platforms[0]);
  properties[2]= 0;
  
  context= clCreateContextFromType(properties, CL_DEVICE_TYPE_ALL, notify, &stderr, &err);
  ERROR(err, "clCreateContextFromType");
  
  err= clGetContextInfo(context, CL_CONTEXT_DEVICES, MAX_DEVICES*sizeof(cl_device_id), devices, &size);
  ERROR(err, "clGetContextInfo");
  err= clGetContextInfo(context, CL_CONTEXT_NUM_DEVICES, sizeof(cl_uint), &numDevices, &size);
  ERROR(err, "clGetContextInfo");
  
  queue= clCreateCommandQueue(context, devices[0], 0, &err);
  ERROR(err, "clCreateCommandQueue");
  
  memobj= clCreateBuffer(context,                  //context object
                         CL_MEM_COPY_HOST_PTR,     //buffer flag
                         ARRAY_SIZE * sizeof(int), //buffer size
                         input,                    //host_ptr
                         &err);                    //pointer to error code variable
  ERROR(err, "clCreateBuffer");
  
  p= (int*)clEnqueueMapBuffer(queue,                           //command queue
                                   memobj,                     //memory object
                                   CL_TRUE,                    //blocking
                                   CL_MAP_READ | CL_MAP_WRITE, //host operations
                                   0,                          //offset
                                   sizeof(int)*ARRAY_SIZE,     //size
                                   0,                          //size of event array
                                   NULL,                       //event array
                                   NULL,                       //output event
                                   &err);                      //pointer to error code variable

  printf("input pointer:\t%p\nmapped pointer:\t%p\n", input, p);
  
  for ( i= 0; i < ARRAY_SIZE; ++i )
    p[i]*= 2;
  
  err= clEnqueueUnmapMemObject(queue,   //command queue
                               memobj,  //memory object
                               p,       //mapped pointer
                               0,       //size of event array
                               NULL,    //event array
                               &event); //output event
  
  err= clEnqueueReadBuffer(queue,                     //commmand queue
                           memobj,                    //puffer object
                           CL_TRUE,                   //blocking
                           sizeof(int)*(ARRAY_SIZE/2),//offset
                           sizeof(int)*(ARRAY_SIZE/2),//size
                           output,                    //output pointer
                           1,                         //size of event array
                           &event,                      //event array
                           NULL);                     //output event
  ERROR(err, "clEnqueueReadBuffer");
  
  for ( i= 0; i < ARRAY_SIZE/2; ++i )
    printf("%d ", output[i]);
  printf("\n");
  
  clReleaseMemObject(memobj);
  clReleaseCommandQueue(queue);
  clReleaseContext(context);
  
  return 0;
}
