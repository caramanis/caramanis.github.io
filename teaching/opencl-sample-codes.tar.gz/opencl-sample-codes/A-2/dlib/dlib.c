#include <stdio.h>
#include <stdarg.h>
#include <dlib.h>

int printfDL(const char* fmt, ...)
{
	va_list args;
	va_start(args, fmt);
	printf("Dynamic Library: ");
	return printf(fmt, args);
}
