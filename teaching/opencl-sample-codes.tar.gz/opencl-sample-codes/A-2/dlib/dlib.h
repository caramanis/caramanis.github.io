#ifndef _DLIB_H_
#define _DLIB_H_

int printfDL(const char* fmt, ...);

#endif