#include <stdio.h>
#include <string.h>

#include <error.h>
#include <kernelio.h>
#include <stopper.h>
#include <openclinit.h>
#include <pngio.h>

#include <CL/opencl.h>

int main(int argc, char** argv)
{
  cl_int err;
  cl_context context;
  cl_command_queue queue;
  cl_mem imgInMem, imgOutMem;
  cl_event event;
  cl_program program;
  cl_kernel kernel;
  cl_uint numDevices;
  cl_device_id devices[MAX_DEVICES];
  char* kernelSource;
  size_t kernelLength;
  size_t global_work_size[2];
  unsigned char *imageIn;
  unsigned int imageOut[256*3]= {0};
  unsigned int rows, columns, imn, i, n;
  unsigned int uc= 0;
  
  createContextAndCommandQueue(&context, &queue, devices, &numDevices);
  
  readPNG(argv[1], &imageIn, &rows, &columns);
  
  imgInMem= clCreateBuffer(context, 0, rows*columns*4*sizeof(unsigned char), NULL, &err);
  imgOutMem= clCreateBuffer(context, 0, 256*3*sizeof(unsigned int), NULL, &err);

  readSourceProgram("histogram.k", &kernelSource, &kernelLength);
  program= clCreateProgramWithSource( context, 1, &kernelSource, NULL, &err);
  ERROR(err, "clCreateProgramWithSource")
    
  err= clBuildProgram(program, numDevices, devices, NULL, NULL, NULL);
  ERROR(err, "clBuildProgram")

  kernel= clCreateKernel(program, "histogram", &err);
  ERROR(err, "clCreateKernel")

  global_work_size[0]= rows;
  global_work_size[1]= columns;
  
  n= rows*columns;

  err= clSetKernelArg(kernel, 0, sizeof(cl_mem), &imgInMem);
  ERROR(err, "clSetKernelArg 0")
  err= clSetKernelArg(kernel, 1, sizeof(cl_mem), &imgOutMem);
  ERROR(err, "clSetKernelArg 1")

  err= clEnqueueWriteBuffer(queue, imgInMem, CL_TRUE, 0, rows*columns*4*sizeof(unsigned char), imageIn, 0, NULL, NULL);
  ERROR(err, "clEnqueueWriteBuffer")

  err= clEnqueueFillBuffer(queue, imgOutMem, &uc, 4, 0, 256*3*sizeof(unsigned int), 0, NULL, &event);
  ERROR(err, "clEnqueueFillBuffer");
  clWaitForEvents(1, &event);

  stopper st;
  startS(&st);
  err= clEnqueueNDRangeKernel(queue, kernel, 2, NULL, global_work_size, NULL, 0, NULL, &event);
  ERROR(err, "clEnqueueNDRangeKernel")

  err= clWaitForEvents(1, &event);
  ERROR(err, "clWaitForEvents")
  stopS(&st);

  err= clEnqueueReadBuffer(queue, imgOutMem, CL_TRUE, 0, 256*3*sizeof(unsigned int), imageOut, 0, NULL, NULL);
  ERROR(err, "clEnqueueReadBuffer")

  /*for ( i= 0; i < 256; ++i )
    printf("%d ", imageOut[i]);
  printf("\n");*/

  clReleaseMemObject(imgInMem);
  clReleaseMemObject(imgOutMem);
  clReleaseCommandQueue(queue);
  clReleaseContext(context);
  
  free(imageIn);
  
  tprintf(&st, "%d\n", rows);

  return 0;
}
