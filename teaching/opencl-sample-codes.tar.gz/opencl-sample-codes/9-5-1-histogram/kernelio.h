#ifndef __KERNEL_IO_H__
#define __KERNEL_IO_H__

void readSourceProgram(char* filename, char** source, size_t* length);

void writeSourceProgram(char* filename, char* source);

void writeBinaryProgram(char* filename, unsigned char** binaries, size_t* lengths, unsigned int n);

void readBinaryProgram(char* filename, unsigned char*** binaries, size_t** lengths, unsigned int* n);

#endif