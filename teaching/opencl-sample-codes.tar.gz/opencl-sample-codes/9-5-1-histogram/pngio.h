#ifndef _PNGIO_H__
#define _PNGIO_H__

#include <stdio.h>

/** PNG kep beolvasasa
 * @param filename a beolvasando fajl neve
 * @return a beolvasott kep mutatoja
 */ 
int readPNG(char* filename, unsigned char** img, unsigned int* rows, unsigned int* columns);

/** kep kiirasa PNG fajlba
 * @param filename a fajl neve
 * @param img a kiirando kep mutatoja
 */ 
int writePNG(char* filename, unsigned char* img, unsigned int rows, unsigned int columns);

#endif