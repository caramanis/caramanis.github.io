#include <openclinit.h>
#include <error.h>

void createContextAndCommandQueue(cl_context *context, cl_command_queue *queue, cl_device_id* devices, cl_uint* numDevices)
{
  cl_int err;
  cl_platform_id platforms[MAX_PLATFORMS];
  cl_context_properties properties[MAX_PLATFORMS*2]= {0};
  cl_uint numPlatforms;
  size_t size;
  int i;
  
  err= clGetPlatformIDs(MAX_PLATFORMS, platforms, &numPlatforms);
  ERROR(err, "clGetPlatformIDs")  

  for ( i= 0; i < numPlatforms; ++i )
  {
    properties[i*2]= (cl_context_properties)CL_CONTEXT_PLATFORM;
    properties[i*2 + 1]= (cl_context_properties)(platforms[i]);
  }
  properties[i*2]= 0;
  
  *context= clCreateContextFromType(properties, CL_DEVICE_TYPE_ALL, NULL, NULL, &err);
  ERROR(err, "clCreateContextFromType")
  
  err= clGetContextInfo(*context, CL_CONTEXT_DEVICES, MAX_DEVICES*sizeof(cl_device_id), devices, &size);
  ERROR(err, "clGetContextInfo")
  err= clGetContextInfo(*context, CL_CONTEXT_NUM_DEVICES, sizeof(cl_uint), numDevices, &size);
  ERROR(err, "clGetContextInfo")
  
  *queue= clCreateCommandQueue(*context, devices[0], 0, &err);
  ERROR(err, "clCreateCommandQueue")
}
