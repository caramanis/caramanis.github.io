#include <stopper.h>
#include <stdarg.h>
#include <stdio.h>
#include <omp.h>

void startS(stopper *st)
{
  st->begin= omp_get_wtime();
}

void stopS(stopper *st)
{
  st->end= omp_get_wtime();
}

int tprintf(stopper *st, const char* fmt, ...)
{
    double d= st->end - st->begin;
    
    va_list arg;
    va_start(arg, fmt);
    printf("%02lf ", d);
    vprintf(fmt, arg);
    va_end(arg);
    fflush(stdout);
}