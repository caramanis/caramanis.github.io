#ifndef _OPENCL_INIT_
#define _OPENCL_INIT_

#define MAX_DEVICES 2
#define MAX_PLATFORMS 2

#include <CL/opencl.h>

/**
 * initialize context and command queue
 * @param context pointer to context object
 * @param queue pointer to queue object
 * @param devices array of devices ids
 * @param numDevices pointer to the number of devices
 */
void createContextAndCommandQueue(cl_context *context, cl_command_queue *queue, cl_device_id* devices, cl_uint* numDevices);

#endif