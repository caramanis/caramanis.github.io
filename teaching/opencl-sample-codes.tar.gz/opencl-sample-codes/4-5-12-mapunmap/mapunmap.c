#include <stdio.h>
#include <error.h>
#include <CL/opencl.h>

#define ARRAY_SIZE 10
#define MAX_DEVICES 2
#define MAX_PLATFORMS 2

void notify(const char* errinfo, const void* private_info, size_t cb, void* user_data)
{
  fprintf(*(FILE**)user_data, "CALLBACK NOTIFICATION: %s\n", errinfo);
}

int main(int argc, char** argv)
{
  cl_int err;
  cl_context context;
  cl_command_queue queue;
  cl_mem memobj;
  cl_event event;
  cl_uint numPlatforms;
  cl_platform_id platforms[MAX_PLATFORMS];
  cl_uint numDevices;
  cl_device_id devices[MAX_DEVICES];
  cl_context_properties properties[3]= {0};
  size_t size;
  
  int input[ARRAY_SIZE];
  int output[ARRAY_SIZE/2];
  int i;
  
  for ( i= 0; i < ARRAY_SIZE; ++i )
    input[i]= i;

  err= clGetPlatformIDs(MAX_PLATFORMS, platforms, &numPlatforms);
  ERROR(err, "clGetPlatformIDs");
  
  properties[0]= (cl_context_properties)CL_CONTEXT_PLATFORM;
  properties[1]= (cl_context_properties)(platforms[0]);
  properties[2]= 0;
  
  context= clCreateContextFromType(properties, CL_DEVICE_TYPE_ALL, notify, &stderr, &err);
  ERROR(err, "clCreateContextFromType");
  
  err= clGetContextInfo(context, CL_CONTEXT_DEVICES, MAX_DEVICES*sizeof(cl_device_id), devices, &size);
  ERROR(err, "clGetContextInfo");
  err= clGetContextInfo(context, CL_CONTEXT_NUM_DEVICES, sizeof(cl_uint), &numDevices, &size);
  ERROR(err, "clGetContextInfo");
  
  queue= clCreateCommandQueue(context, devices[0], 0, &err);
  ERROR(err, "clCreateCommandQueue");
  
  memobj= clCreateBuffer(context,                                       //context object
                         CL_MEM_ALLOC_HOST_PTR | CL_MEM_COPY_HOST_PTR,  //buffer flags
                         ARRAY_SIZE * sizeof(int),                      //size
                         input,                                         //host pointer
                         &err);                                         //pointer to error code variable
  ERROR(err, "clCreateBuffer");
  
  err= clEnqueueWriteBuffer(queue, memobj, 1, 0, sizeof(int)*ARRAY_SIZE, input, 0, NULL, NULL);
  ERROR(err, "clEnqueueWriteBuffer");
  
  int* pointer= (int*)clEnqueueMapBuffer( queue, memobj, CL_TRUE, CL_MAP_READ | CL_MAP_WRITE, 0, sizeof(int)*ARRAY_SIZE, 0, NULL, NULL, &err);

  printf("input pointer:\t%p\nmapped pointer:\t%p\n", input, pointer);
  
  for ( i= 0; i < ARRAY_SIZE; ++i )
    pointer[i]*= 2;
  
  err= clEnqueueUnmapMemObject(queue, memobj, pointer, 0, NULL, &event);
  
  err= clWaitForEvents(1, &event);
  
  err= clEnqueueReadBuffer(queue, memobj, 1, sizeof(int)*(ARRAY_SIZE/2), sizeof(int)*(ARRAY_SIZE/2), output, 0, NULL, NULL);
  ERROR(err, "clEnqueueReadBuffer");
  
  for ( i= 0; i < ARRAY_SIZE/2; ++i )
    printf("%d ", output[i]);
  printf("\n");
  
  clReleaseMemObject(memobj);
  clReleaseCommandQueue(queue);
  clReleaseContext(context);
  
  return 0;
}
