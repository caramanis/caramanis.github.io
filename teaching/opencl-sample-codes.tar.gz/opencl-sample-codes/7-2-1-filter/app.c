#include <stdio.h>
#include <string.h>

#include <error.h>
#include <stopper.h>
#include <filter.h>

int main(int argc, char** argv)
{
  float *imageIn, *imageOut, *weights, f;
  unsigned int rows, columns, imn, i, n, j;
  int* pos;
  stopper st;
  
  readPGM(argv[1], &imageIn, &rows, &columns);
  generateGaussianFilter(atof(argv[2]), columns, &weights, &pos, &n);
  imageOut= (float*)malloc(sizeof(float)*rows*columns);
  imn= rows*columns;
  
  startS(&st);

  for ( i= 0; i < imn; ++i )
  {
    f= 0;
    for ( j= 0; j < n; ++j )
      if ( i + pos[j] >= 0 && i + pos[j] < imn )
        f+= imageIn[i + pos[j]]*weights[j];
    imageOut[i]= f;
  }
  
  stopS(&st);

  writePGM(argv[3], imageOut, rows, columns);
  
  free(imageIn);
  free(imageOut);
  free(weights);
  free(pos);
  
  tprintf(&st, "%f\n", atof(argv[2]));
  
  return 0;
}