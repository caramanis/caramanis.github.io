#include <filter.h>
#include <math.h>

void generateGaussianFilter(float sigma, int columns, float** weights, int** positions, unsigned int* n)
{
  int min= -3*sigma, max= 3*sigma;
  int i, j, k= 0;
  float c= 2*sigma*sigma;
  *weights= (float*)malloc(sizeof(float)*MAX_FILTER_SIZE);
  *positions= (int*)malloc(sizeof(int)*MAX_FILTER_SIZE);

  for ( i= min; i <= max; ++i )
    for ( j= min; j <= max; ++j )
      if ( i*i + j*j <= 9*sigma*sigma )
      {
        (*weights)[k]= 1.0/(M_PI*c)*exp(-(i*i + j*j)/c);
        (*positions)[k++]= i*columns + j;
      }

  *n= k;
  *weights= (float*)realloc(*weights, sizeof(float)*k);
  *positions= (int*)realloc(*positions, sizeof(int)*k);
}