#! /bin/bash

for I in `ls -d 5-*/`
do
  echo "=== BUILDING ${I} ==="
  cd ${I}
  KERNELS=`ls *.k`
  for K in ${KERNELS}
  do
    ../compiler/occc ${K} ${K%.k}.b
  done
  cd ..
done