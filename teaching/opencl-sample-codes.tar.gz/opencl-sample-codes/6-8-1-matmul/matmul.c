#include <stdio.h>
#include <string.h>
#include <error.h>
#include <kernelio.h>
#include <stopper.h>
#include <openclinit.h>
#include <CL/opencl.h>

void printSM(float* m, int n)
{
  int i, j;
  for ( i= 0; i < n; ++i )
  {
    for ( j= 0; j < n; ++j )
      printf("%.0f ", m[i*n + j]);
    printf("\n");
  }
  printf("\n");
}

int main(int argc, char** argv)
{
  cl_int err;
  cl_context context;
  cl_command_queue queue;
  cl_mem matrixA, matrixB, matrixC;
  int i, n;
  cl_event event;
  cl_uint numDevices;
  cl_device_id devices[MAX_DEVICES];
  cl_uint size;
  cl_program program;
  cl_kernel kernel;
  char* kernelSource;
  size_t kernelLength;
  float *A, *B, *C;
  size_t global_work_size[2], local_work_size[2];
  char flags[100];
  
  n= atoi(argv[1]);
  global_work_size[0]= n;
  if ( n >= 32 )
    local_work_size[0]= local_work_size[1]= 16;
  else
    local_work_size[0]= local_work_size[1]= n/2;

  A= (float*)malloc(sizeof(float)*n*n);
  B= (float*)malloc(sizeof(float)*n*n);
  C= (float*)malloc(sizeof(float)*n*n);  
  
  for ( i= 0; i < n*n; ++i )
  {
    A[i]= rand()%10;
    B[i]= rand()%10;
  }

  createContextAndCommandQueue(&context,&queue, devices, &numDevices);
  
  matrixA= clCreateBuffer(context, 0, n*n*sizeof(float), NULL, &err);
  ERROR(err, "clCreateBuffer")
  matrixB= clCreateBuffer(context, 0, n*n*sizeof(float), NULL, &err);
  ERROR(err, "clCreateBuffer")
  matrixC= clCreateBuffer(context, 0, n*n*sizeof(float), NULL, &err);
  ERROR(err, "clCreateBuffer")
  
  readSourceProgram("matrixMultiplication.k", &kernelSource, &kernelLength);
  program= clCreateProgramWithSource( context, 1, (const char**)&kernelSource, NULL, &err);
  ERROR(err, "clCreateProgramWithSource")

  sprintf(flags, "-DM=%d", n);
  err= clBuildProgram(program, numDevices, devices, flags, NULL, NULL);
  ERROR(err, "clBuildProgram")
  
  kernel= clCreateKernel(program, "matrixMultiplication", &err);
  ERROR(err, "clCreateKernel")

  err= clEnqueueWriteBuffer(queue, matrixA, 1, 0, sizeof(float)*n*n, A, 0, NULL, NULL);
  ERROR(err, "clEnqueueWriteBuffer")
  err= clEnqueueWriteBuffer(queue, matrixB, 1, 0, sizeof(float)*n*n, B, 0, NULL, NULL);
  ERROR(err, "clEnqueueWriteBuffer")
  
  err= clSetKernelArg(kernel, 0, sizeof(cl_mem), &matrixA);
  ERROR(err, "clSetKernelArg")
  err= clSetKernelArg(kernel, 1, sizeof(cl_mem), &matrixB);
  ERROR(err, "clSetKernelArg")
  err= clSetKernelArg(kernel, 2, sizeof(cl_mem), &matrixC);
  ERROR(err, "clSetKernelArg")
  
  stopper st;
  startS(&st);
  err= clEnqueueNDRangeKernel(queue, kernel, 1, NULL, global_work_size, local_work_size, 0, NULL, &event); 
  ERROR(err, "clEnqueueNDRangeKernel")
  clWaitForEvents(1, &event);
  stopS(&st);

  err= clEnqueueReadBuffer(queue, matrixC, 1, 0, sizeof(float)*n*n, C, 0, NULL, NULL);
  ERROR(err, "clEnqueueReadBuffer")
  
/*  printSM(A, n);
  printSM(B, n);
  printSM(C, n);*/
  
  clReleaseMemObject(matrixA);
  clReleaseMemObject(matrixB);
  clReleaseMemObject(matrixC);
  clReleaseKernel(kernel);
  clReleaseProgram(program);
  clReleaseCommandQueue(queue);
  clReleaseContext(context);
  
  free(kernelSource);
  free(A);
  free(B);
  free(C);
  
  tprintf(&st, "%d\n", n);
  
  return 0;
}