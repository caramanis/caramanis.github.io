#ifndef _PGM_H_
#define _PGM_H_

#include <stdio.h>

/** PGM kep beolvasasa
 * @param filename a beolvasando fajl neve
 * @return a beolvasott kep mutatoja
 */ 
int readPGM(char* filename, float** img, unsigned int* rows, unsigned int* columns);

/** kep kiirasa PGM fajlba
 * @param filename a fajl neve
 * @param img a kiirando kep mutatoja
 */ 
int writePGM(char* filename, float* img, unsigned int rows, unsigned int columns);

#endif