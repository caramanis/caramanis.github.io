#include <stdio.h>
#include <string.h>
#include <error.h>
#include <kernelio.h>
#include <CL/opencl.h>
#include <GL/glut.h>
#include <math.h>

#define MAX_DEVICES 2
#define MAX_PLATFORMS 2

// OpenCL global variables
cl_context context;
cl_command_queue queue;
cl_mem rMem, vMem, tmpMem;
cl_program program;
cl_kernel simulationKernel;

size_t global_work_size[2], local_work_size[2];
float dt, *r, *v;
int N;

// OpenGL global variables 
int theta= 45, phi= 45, R= 1;
int buttonDown= 0, xOld, yOld, thetaOld, phiOld;
float scale= 100;
GLuint buffer;

void oneIteration()
{
  cl_uint err;
  cl_event event[2];
  
  err= clEnqueueAcquireGLObjects(queue, 1, &tmpMem, 0, NULL, NULL);
  ERROR(err, "clEnqueueAcquireGLObjects")
  
  err= clEnqueueNDRangeKernel(queue, simulationKernel, 1, NULL, global_work_size, local_work_size, 0, NULL, event); 
  ERROR(err, "clEnqueueNDRangeKernel")
    
  err= clEnqueueCopyBuffer(queue, tmpMem, rMem, 0, 0, sizeof(float)*4*N, 1, event, event + 1);
  ERROR(err, "clEnqueueCopyBuffer")
  
  clWaitForEvents(1, event + 1);
  ERROR(err, "clWaitForEvents")

  clEnqueueReleaseGLObjects(queue, 1, &tmpMem, 0, NULL, NULL);
  ERROR(err, "clEnqueueReleaseGLObjects")
  
  err= clFinish(queue);
  ERROR(err, "clFinish")
  
  glutPostRedisplay();
}

void initObjects()
{
  int i;
  for ( i= 0; i < N; i++ )
  {
    r[4*i]= ((float)rand())/RAND_MAX*2-1;
    r[4*i+1]= ((float)rand())/RAND_MAX*2-1;
    r[4*i+2]= ((float)rand())/RAND_MAX*2-1;
    r[4*i+3]= ((float)rand())/RAND_MAX;
    v[4*i]= ((float)rand())/RAND_MAX*2-1;
    v[4*i+1]= ((float)rand())/RAND_MAX*2-1;
    v[4*i+2]= ((float)rand())/RAND_MAX*2-1;
    v[4*i+3]= 0;
  }
}

void clInit(int argc, char** argv)
{
  cl_int err;
  cl_uint numDevices;
  cl_device_id devices[MAX_DEVICES];
  cl_uint numPlatforms;
  cl_platform_id platforms[MAX_PLATFORMS];
  cl_context_properties properties[MAX_PLATFORMS*2]= {0};
  size_t size;
  char* kernelSource;
  size_t kernelLength;
  unsigned int i;
  
  N= atoi(argv[1]);
  dt= atof(argv[2]);
  
  r= (float*)malloc(sizeof(float)*N*4);
  v= (float*)malloc(sizeof(float)*N*4);
  
  initObjects();

  global_work_size[0]= N;
  if ( N % 256 == 0 )
    local_work_size[0]= 256;
  else if ( N % 4 == 0 )
    local_work_size[0]= N/4;
  else
    local_work_size[0]= 1;
  
  err= clGetPlatformIDs(MAX_PLATFORMS, platforms, &numPlatforms);
  ERROR(err, "clGetPlatformIDs")  

  properties[0]= (cl_context_properties)CL_CONTEXT_PLATFORM;
  properties[1]= (cl_context_properties)(platforms[0]);
  properties[2]= 0;
  
  err= clGetDeviceIDs(platforms[0], CL_DEVICE_TYPE_ALL, MAX_DEVICES, devices, &numDevices);
  ERROR(err, "clGetDeviceIDs")
 
  cl_context_properties props[]= {CL_GL_CONTEXT_KHR, (cl_context_properties)glXGetCurrentContext(),
                                  CL_GLX_DISPLAY_KHR, (cl_context_properties)glXGetCurrentDisplay(),
                                  CL_CONTEXT_PLATFORM, (cl_context_properties)platforms[0],
                                  0};

  context= clCreateContext(props, 1, devices, NULL, NULL, &err);
  ERROR(err, "clCreateContext")
  
  queue= clCreateCommandQueue(context, devices[0], 0, &err);
  ERROR(err, "clCreateCommandQueue")
  
  rMem= clCreateBuffer(context, 0, N*4*sizeof(float), NULL, &err);
  ERROR(err, "clCreateBuffer")
  vMem= clCreateBuffer(context, 0, N*4*sizeof(float), NULL, &err);
  ERROR(err, "clCreateBuffer")
  tmpMem= clCreateFromGLBuffer(context, CL_MEM_READ_WRITE, buffer, &err);
  ERROR(err, "clCreateBuffer")    
  
  readSourceProgram("simulation.k", &kernelSource, &kernelLength);
  program= clCreateProgramWithSource( context, 1, &kernelSource, NULL, &err);
  ERROR(err, "clCreateProgramWithSource")
  
  err= clBuildProgram(program, numDevices, devices, NULL, NULL, NULL);
  ERROR(err, "clBuildProgram")
  
  simulationKernel= clCreateKernel(program, "simulation", &err);
  ERROR(err, "clCreateKernel")

  err= clEnqueueWriteBuffer(queue, rMem, CL_TRUE, 0, sizeof(float)*4*N, r, 0, NULL, NULL);
  ERROR(err, "clEnqueueWriteBuffer")
  err= clEnqueueWriteBuffer(queue, vMem, CL_TRUE, 0, sizeof(float)*4*N, v, 0, NULL, NULL);
  ERROR(err, "clEnqueueWriteBuffer")
  
  err= clEnqueueAcquireGLObjects(queue, 1, &tmpMem, 0, NULL, NULL);
  ERROR(err, "clEnqueueAcquireGLObjects")
  err= clEnqueueWriteBuffer(queue, tmpMem, CL_TRUE, 0, sizeof(float)*4*N, r, 0, NULL, NULL);
  ERROR(err, "clEnqueueWriteBuffer")
  clEnqueueReleaseGLObjects(queue, 1, &tmpMem, 0, NULL, NULL);
  ERROR(err, "clEnqueueReleaseGLObjects")
  err= clFinish(queue);
  ERROR(err, "clFinish")

  err= clSetKernelArg(simulationKernel, 0, sizeof(cl_mem), &rMem);
  ERROR(err, "clSetKernelArg 0")
  err= clSetKernelArg(simulationKernel, 1, sizeof(cl_mem), &vMem);
  ERROR(err, "clSetKernelArg 1")
  err= clSetKernelArg(simulationKernel, 2, sizeof(cl_mem), &tmpMem);
  ERROR(err, "clSetKernelArg 2")
  err= clSetKernelArg(simulationKernel, 3, sizeof(cl_float), &dt);
  ERROR(err, "clSetKernelArg 3")
  err= clSetKernelArg(simulationKernel, 4, sizeof(cl_float)*4*local_work_size[0], NULL);
  ERROR(err, "clSetKernelArg 4")

  free(kernelSource);
}

void clFinalize()
{
  cl_uint err;
  
  err= clReleaseMemObject(rMem); ERROR(err, "clReleaseMemObject")
  err= clReleaseMemObject(vMem); ERROR(err, "clReleaseMemObject")
  err= clReleaseMemObject(tmpMem); ERROR(err, "clReleaseMemObject")
  err= clReleaseKernel(simulationKernel); ERROR(err, "clReleaseKernel")
  err= clReleaseProgram(program); ERROR(err, "clReleaseProgram")
  err= clReleaseCommandQueue(queue); ERROR(err, "clReleaseCommandQueue")
  err= clReleaseContext(context); ERROR(err, "clReleaseContext")
  
  free(r);
  free(v);
}

void display(void) 
{
  int i;

  glClear(GL_COLOR_BUFFER_BIT);
  glColor3f(255, 255, 255);
  glPushMatrix();
  glScalef(scale, scale, scale);
  gluLookAt( R*sin(phi*M_PI/180)*cos(theta*M_PI/180),
             R*sin(phi*M_PI/180)*sin(theta*M_PI/180),
             R*cos(phi*M_PI/180), 0, 0, 0, 0, 0, 1);
  
  glBegin(GL_LINES);
  glVertex3i(0,0,0);
  glVertex3i(1,0,0);
  glVertex3i(0,0,0);
  glVertex3i(0,1,0);
  glVertex3i(0,0,0);
  glVertex3i(0,0,1);
  glEnd();

  glColor3f(255, 255, 0);  
  
  glBindBuffer(GL_ARRAY_BUFFER, buffer);
  glVertexPointer(3, GL_FLOAT, sizeof(float)*4, 0);
  
  glEnableClientState(GL_VERTEX_ARRAY);
  glDrawArrays(GL_POINTS, 0, N);
  glDisableClientState(GL_VERTEX_ARRAY);
  
  glPopMatrix();
  glutSwapBuffers();
}

void mouse(int button, int state, int x, int y)
{
  if( button == GLUT_LEFT_BUTTON && state == GLUT_DOWN ) 
  {
    buttonDown= 1;
    xOld= x;
    yOld= y;
    phiOld= phi;
    thetaOld= theta;
  }
  else if ( button == GLUT_LEFT_BUTTON && state != GLUT_DOWN )
    buttonDown= 0;
  else if ( button == 3 )
    scale+= 10;
  else if ( button == 4 )
    scale-= 10;
}
void motion(int x, int y) 
{
  if (buttonDown) 
  {
    phi= (phiOld - (y - yOld)) % 360;
    theta= (thetaOld - (x - xOld)) % 360;
    glutPostRedisplay();
  }
}

void reshape(int width, int height) 
{
  glViewport(0, 0, width, height);
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  glOrtho(-300, 300, -300, 300, -300, 300);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
}

void glInit(int argc,char *argv[]) 
{
  glutInit(&argc,argv);
  glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
  glutInitWindowSize(800, 800);
  glutInitWindowPosition(50, 50);
  glutCreateWindow("Gravitation simulation");
  glutDisplayFunc(display);
  glutReshapeFunc(reshape);
  glutMouseFunc(mouse);
  glutMotionFunc(motion);
  glutIdleFunc(oneIteration);
  glewInit();
  
  glGenBuffers(1, &buffer);
  glBindBuffer(GL_ARRAY_BUFFER_ARB, buffer);
  glBufferData(GL_ARRAY_BUFFER_ARB, N*sizeof(float)*4, NULL, GL_DYNAMIC_DRAW_ARB);

  glVertexPointer(4, GL_FLOAT, 0, 0);
  glBindBuffer(GL_ARRAY_BUFFER_ARB, 0);
}

int main(int argc, char** argv)
{
  glInit(argc, argv);
  clInit(argc, argv);
  
  glutMainLoop();
  
  clFinalize();

  return 0;
}