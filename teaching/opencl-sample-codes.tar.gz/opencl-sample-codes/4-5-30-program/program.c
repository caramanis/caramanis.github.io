#include <stdio.h>
#include <stdlib.h>
#include <error.h>
#include <kernelio.h>
#include <CL/opencl.h>

#define MAX_DEVICES 5
#define MAX_PLATFORMS 5

int main(int argc, char** argv)
{
  cl_int err;
  cl_context context;
  cl_command_queue queue;
  cl_uint numPlatforms;
  cl_platform_id platforms[MAX_PLATFORMS];
  cl_uint numDevices;
  cl_device_id devices[MAX_DEVICES];
  cl_context_properties properties[3]= {0};
  size_t size;
  cl_program program;
  char* source, filename[1000], buildLog[1000];
  size_t sourceLength;
  int i;
  size_t* binaryLengths;
  unsigned char** binaryCodes;
  
  err= clGetPlatformIDs(MAX_PLATFORMS, platforms, &numPlatforms);
  ERROR(err, "clGetPlatformIDs");
  
  properties[0]= (cl_context_properties)CL_CONTEXT_PLATFORM;
  properties[1]= (cl_context_properties)(platforms[0]);
  properties[2]= 0;
  
  context= clCreateContextFromType(properties, CL_DEVICE_TYPE_ALL, &notify, &stderr, &err);
  ERROR(err, "clCreateContextFromType");
  
  err= clGetContextInfo(context, CL_CONTEXT_DEVICES, MAX_DEVICES*sizeof(cl_device_id), devices, &size);
  ERROR(err, "clGetContextInfo");
  err= clGetContextInfo(context, CL_CONTEXT_NUM_DEVICES, sizeof(cl_uint), &numDevices, &size);
  ERROR(err, "clGetContextInfo");
  
  queue= clCreateCommandQueue(context, devices[0], 0, &err);
  ERROR(err, "clCreateCommandQueue");
  
  readSourceProgram("secondOrder.k", 
                    &source, 
                    &sourceLength);
  
  program= clCreateProgramWithSource(context, 
                                     1, 
                                     (void*)&source, 
                                     &sourceLength, 
                                     &err);
  ERROR(err, "clCreateProgramWithSource");
  
  err= clBuildProgram(program, 
                      numDevices, 
                      devices, 
                      "-cl-kernel-arg-info", 
                      NULL, 
                      NULL);
  ERROR(err, "clBuildProgram");

  for ( i= 0; i < numDevices; ++i )
  {
    err= clGetProgramBuildInfo(program,
                               devices[i],
                               CL_PROGRAM_BUILD_LOG,
                               1000,
                               &(buildLog),
                               &size);
    ERROR(err, "clGetProgramBuildInfo");
    printf("%s\n", buildLog);
  }
  
  binaryLengths= (size_t*)malloc(sizeof(size_t)*numDevices);
  binaryCodes= (unsigned char**)malloc(sizeof(unsigned char*)*numDevices);
  
  err= clGetProgramInfo(program, 
			CL_PROGRAM_BINARY_SIZES, 
			sizeof(size_t)*numDevices, 
			(binaryLengths), 
			&size);
  ERROR(err, "clGetProgramInfo");
  
  for ( i= 0; i < numDevices; ++i )
    binaryCodes[i]= (unsigned char*)malloc(sizeof(unsigned char)*(binaryLengths[i]));
  
  err= clGetProgramInfo(program, 
			CL_PROGRAM_BINARIES, 
			sizeof(unsigned char*)*numDevices, 
			(binaryCodes), 
			&size);
  ERROR(err, "clGetProgramInfo");

  writeBinaryProgram("secondOrder.b", binaryCodes, binaryLengths, numDevices);

  clReleaseProgram(program);
  clReleaseCommandQueue(queue);
  clReleaseContext(context);
  
  free(source);
  for ( i= 0; i < numDevices; ++i )
    free(binaryCodes[i]);
  free(binaryCodes);
  free(binaryLengths);
  
  return 0;
}
