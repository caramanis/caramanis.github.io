#include <stdio.h>
#include <error.h>

void notify(const char* errinfo, const void* private_info, size_t cb, void* user_data)
{
  fprintf(*(FILE**)user_data, "CALLBACK NOTIFICATION: %s\n", errinfo);
}

void errorMessage(FILE* out, int err, const char* prefix)
{
  switch(err)
  {
    case CL_SUCCESS: fprintf(out, "%s: Success.\n", prefix); break;
    case CL_DEVICE_NOT_FOUND: fprintf(out, "%s: Device not found.\n", prefix); break;
    case CL_DEVICE_NOT_AVAILABLE: fprintf(out, "%s: Device not available.\n", prefix); break;
    case CL_COMPILER_NOT_AVAILABLE: fprintf(out, "%s: Compiler not available.\n", prefix); break;
    case CL_MEM_OBJECT_ALLOCATION_FAILURE: fprintf(out, "%s: Memory object application failure.\n", prefix); break;
    case CL_OUT_OF_RESOURCES: fprintf(out, "%s: Out of resources.\n", prefix); break;
    case CL_OUT_OF_HOST_MEMORY: fprintf(out, "%s: Out of host memory.\n", prefix); break;
    case CL_PROFILING_INFO_NOT_AVAILABLE: fprintf(out, "%s: Profiling information not available.\n", prefix); break;
    case CL_MEM_COPY_OVERLAP: fprintf(out, "%s: Memory copy overlap.\n", prefix); break;
    case CL_IMAGE_FORMAT_MISMATCH: fprintf(out, "%s: Image format mismatch.\n", prefix); break;
    case CL_IMAGE_FORMAT_NOT_SUPPORTED: fprintf(out, "%s: Image format not supported.\n", prefix); break;
    case CL_BUILD_PROGRAM_FAILURE: fprintf(out, "%s: Program build failure.\n", prefix); break;
    case CL_MAP_FAILURE: fprintf(out, "%s: Map failure.\n", prefix); break;
    case CL_INVALID_VALUE: fprintf(out, "%s: Invalid value.\n", prefix); break;
    case CL_INVALID_DEVICE_TYPE: fprintf(out, "%s: Invalid device type.\n", prefix); break;
    case CL_INVALID_PLATFORM: fprintf(out, "%s: Invalid platform.\n", prefix); break;
    case CL_INVALID_DEVICE: fprintf(out, "%s: Invalid device.\n", prefix); break;
    case CL_INVALID_CONTEXT: fprintf(out, "%s: Invalid context.\n", prefix); break;
    case CL_INVALID_QUEUE_PROPERTIES: fprintf(out, "%s: Invalid queue properties.\n", prefix); break;
    case CL_INVALID_COMMAND_QUEUE: fprintf(out, "%s: Invalid command queue.\n", prefix); break;
    case CL_INVALID_HOST_PTR: fprintf(out, "%s: Invalid host pointer.\n", prefix); break;
    case CL_INVALID_MEM_OBJECT: fprintf(out, "%s: Invalid memory object.\n", prefix); break;
    case CL_INVALID_IMAGE_FORMAT_DESCRIPTOR: fprintf(out, "%s: Invalid image format descriptor.\n", prefix); break;
    case CL_INVALID_IMAGE_SIZE: fprintf(out, "%s: Invalid image size.\n", prefix); break;
    case CL_INVALID_SAMPLER: fprintf(out, "%s: Invalid sampler.\n", prefix); break;
    case CL_INVALID_BINARY: fprintf(out, "%s: Invalid binary.\n", prefix); break;
    case CL_INVALID_BUILD_OPTIONS: fprintf(out, "%s: Invalid build options.\n", prefix); break;
    case CL_INVALID_PROGRAM: fprintf(out, "%s: Invalid program.\n", prefix); break;
    case CL_INVALID_PROGRAM_EXECUTABLE: fprintf(out, "%s: Invalid program executable.\n", prefix); break;
    case CL_INVALID_KERNEL_NAME: fprintf(out, "%s: Invalid kernel name.\n", prefix); break;
    case CL_INVALID_KERNEL_DEFINITION: fprintf(out, "%s: Invalid kernel definition.\n", prefix); break;
    case CL_INVALID_KERNEL: fprintf(out, "%s: Invalid kernel.\n", prefix); break;
    case CL_INVALID_ARG_INDEX: fprintf(out, "%s: Invalid argument index.\n", prefix); break;
    case CL_INVALID_ARG_VALUE: fprintf(out, "%s: Invalid argument value.\n", prefix); break;
    case CL_INVALID_ARG_SIZE: fprintf(out, "%s: Invalid argument size.\n", prefix); break;
    case CL_INVALID_KERNEL_ARGS: fprintf(out, "%s: Invalid kernel arguments.\n", prefix); break;
    case CL_INVALID_WORK_DIMENSION: fprintf(out, "%s: Invalid work dimension.\n", prefix); break;
    case CL_INVALID_WORK_GROUP_SIZE: fprintf(out, "%s: Invalid work group size.\n", prefix); break;
    case CL_INVALID_WORK_ITEM_SIZE: fprintf(out, "%s: Invalid work item size.\n", prefix); break;
    case CL_INVALID_GLOBAL_OFFSET: fprintf(out, "%s: Invalid global offset.\n", prefix); break;
    case CL_INVALID_EVENT_WAIT_LIST: fprintf(out, "%s: Invalid event wait list.\n", prefix); break;
    case CL_INVALID_EVENT: fprintf(out, "%s: Invalid event.\n", prefix); break;
    case CL_INVALID_OPERATION: fprintf(out, "%s: Invalid operation.\n", prefix); break;
    case CL_INVALID_GL_OBJECT: fprintf(out, "%s: Invalid OpenGL object.\n", prefix); break;
    case CL_INVALID_BUFFER_SIZE: fprintf(out, "%s: Invalid buffer size.\n", prefix); break;
    case CL_INVALID_MIP_LEVEL: fprintf(out, "%s: Invalid mip-map level.\n", prefix); break;
    default: fprintf(out, "%s: Unknown error.\n", prefix); break;
  }
  fflush(out);
}