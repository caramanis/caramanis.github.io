#! /bin/bash

./clean.sh
./build-apps.sh
./build-kernels.sh
./test-matmul.sh
./test-filter.sh
./test-histogram.sh
./test-dft.sh
./test-simulate.sh
