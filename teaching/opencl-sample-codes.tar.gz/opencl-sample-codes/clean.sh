#! /bin/bash

for I in `ls -d */`
do
  if [[ -f ${I}/CMakeLists.txt ]]
  then
    cd ${I}
    make clean
    rm -rf CMakeFiles
    rm CMakeCache.txt
    rm cmake_install.cmake
    rm Makefile
    rm *.b
    cd ..
  else
    cd ${I}
    rm *.b
    cd ..
  fi
done

rm -rf test-*-results
