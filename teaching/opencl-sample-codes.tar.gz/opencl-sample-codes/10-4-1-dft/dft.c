#include <stdio.h>
#include <string.h>
#include <stopper.h>
#include <math.h>
#include <stdlib.h>

void printF(float* m, int N)
{
  int i;
  for ( i= 0; i < 2*N; i+= 2 )
    printf("(%.1f, %.1f) ", m[i], m[i+1]);
  printf("\n");
}

void dft(float* f, float* F, int N)
{
  int k, n;
  for ( k= 0; k < N; ++k )
  {
    F[2*k]= 0;
    F[2*k+1]= 0;
    for ( n= 0; n < N; ++n )
    {
      F[2*k]+= f[2*n]*cos(2*M_PI*k*n/N) + f[2*n+1]*sin(2*M_PI*k*n/N);
      F[2*k+1]+= f[2*n+1]*cos(2*M_PI*k*n/N) - f[2*n]*sin(2*M_PI*k*n/N);
    }
  }
}

void idft(float* F, float* f, int N)
{
  int k, n;
  for ( n= 0; n < N; ++n )
  {
    f[2*n]= 0;
    f[2*n+1]= 0;
    for ( k= 0; k < N; ++k )
    {
      f[2*n]+= F[2*k]*cos(2*M_PI*n*k/N) - F[2*k+1]*sin(2*M_PI*n*k/N);
      f[2*n+1]+= F[2*k+1]*cos(2*M_PI*n*k/N) + F[2*k]*sin(2*M_PI*n*k/N);
    }
    f[2*n]/= (float)N;
    f[2*n+1]/= (float)N;
  }
}

int main(int argc, char** argv)
{
  int i, j, k, N;
  float *f, *F, *g;
  
  N= atoi(argv[1]);

  f= (float*)malloc(sizeof(float)*2*N);
  g= (float*)malloc(sizeof(float)*2*N);
  F= (float*)malloc(sizeof(float)*2*N);
  
  for ( i= 0; i < 2*N; i+= 2 )
  {
    f[i]= rand()%10;
    f[i+1]= 0;
  }

  stopper st;
  startS(&st);

  dft(f, F, N);
  idft(F, g, N);
  
  stopS(&st);
  
/*  printF(f, N);
  printF(F, N);
  printF(g, N);*/

  free(f);
  free(g);
  free(F);
  
  tprintf(&st, "%d\n", N);
  
  return 0;
}
