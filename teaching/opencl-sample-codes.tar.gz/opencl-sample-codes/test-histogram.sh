#! /bin/bash

PARAMETERS="512 768 1024 1280 1536 1792 2048"
REPEATS=3
POSTFIX=histogram
OUTPUTDIR=test-${POSTFIX}-results

rm -rf ${OUTPUTDIR}
mkdir ${OUTPUTDIR}

for I in `ls -d *-${POSTFIX}`
do
  cd ${I}
  make clean
  rm CMakeCache.txt
  cmake -DCMAKE_BUILD_TYPE=release -r .
  make
  cd ..

  OUTPUTFILE=${I}-results.txt
  touch ${OUTPUTDIR}/${OUTPUTFILE}
  cd ${I}
  for P in ${PARAMETERS}
  do
    for R in `seq 1 1 ${REPEATS}`
    do
      COMMAND="./${POSTFIX} ../testimages/lena${P}.png"
      echo "${COMMAND}"
      ${COMMAND} >> ../${OUTPUTDIR}/${OUTPUTFILE}
    done
  done
  cd ..
done

cp figures-${POSTFIX}.R ${OUTPUTDIR}
cd ${OUTPUTDIR}
Rscript figures-${POSTFIX}.R ${REPEATS}
cd ..