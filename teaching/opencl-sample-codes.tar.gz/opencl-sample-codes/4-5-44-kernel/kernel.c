#include <stdio.h>
#include <stdlib.h>
#include <error.h>
#include <kernelio.h>
#include <CL/opencl.h>

#define MAX_DEVICES 2
#define MAX_PLATFORMS 2
#define MAX_KERNELS 10

#define MAX_STRING_LENGTH 10000

int main(int argc, char** argv)
{
  cl_int err;
  cl_context context;
  cl_command_queue queue;
  cl_uint numPlatforms;
  cl_platform_id platforms[MAX_PLATFORMS];
  cl_uint numDevices;
  cl_device_id devices[MAX_DEVICES];
  cl_context_properties properties[3]= {0};
  size_t size;
  cl_program program;
  int i, j;
  size_t* binaryLength;
  unsigned char** binaryCode;
  cl_kernel kernels[MAX_KERNELS];
  cl_uint numKernels;
  cl_uint numArgs;
  char pString[MAX_STRING_LENGTH];
  unsigned int n;
  cl_int status[MAX_DEVICES];
  
  err= clGetPlatformIDs(MAX_PLATFORMS, platforms, &numPlatforms);
  ERROR(err, "clGetPlatformIDs");
  
  properties[0]= (cl_context_properties)CL_CONTEXT_PLATFORM;
  properties[1]= (cl_context_properties)(platforms[0]);
  properties[2]= 0;
  
  context= clCreateContextFromType(properties, CL_DEVICE_TYPE_ALL, notify, &stderr, &err);
  ERROR(err, "clCreateContextFromType");
  
  err= clGetContextInfo(context, CL_CONTEXT_DEVICES, MAX_DEVICES*sizeof(cl_device_id), &devices, &size);
  ERROR(err, "clGetContextInfo");
  err= clGetContextInfo(context, CL_CONTEXT_NUM_DEVICES, sizeof(cl_uint), &numDevices, &size);
  ERROR(err, "clGetContextInfo");
  
  queue= clCreateCommandQueue(context, devices[0], 0, &err);
  ERROR(err, "clCreateCommandQueue");
  
  readBinaryProgram(argv[1], &binaryCode, &binaryLength, &n);
  
  program= clCreateProgramWithBinary(context, numDevices, devices, binaryLength, binaryCode, status, &err);
  ERROR(err, "clCreateProgramWithBinary");
  
  err= clBuildProgram(program, numDevices, devices, "-cl-kernel-arg-info", NULL, NULL);

  err= clCreateKernelsInProgram( program,
                                 MAX_KERNELS,
                                 kernels,
                                 &numKernels);
  ERROR(err, "clCreateKernelsInProgram");
  
  for ( i= 0; i < numKernels; ++i )
  {
    err= clGetKernelInfo(kernels[i], CL_KERNEL_FUNCTION_NAME, MAX_STRING_LENGTH, &pString, &size);
    ERROR(err, "clGetKernelInfo");
    printf("kernel name: %s\n", pString);
    
    err= clGetKernelInfo(kernels[i], CL_KERNEL_NUM_ARGS, sizeof(numArgs), &numArgs, &size);
    ERROR(err, "clGetKernelInfo");
    printf("number of args: %d\n", numArgs);

    for ( j= 0; j < numArgs; ++j )
    {
      err= clGetKernelArgInfo( kernels[i],
                               j,
                               CL_KERNEL_ARG_NAME,
                               MAX_STRING_LENGTH,
                               &pString,
                               &size);
      ERROR(err, "clGetKernelArgInfo");
      printf("\tkernel arg type name: %s\n", pString);
      
      err= clGetKernelArgInfo( kernels[i],
                               j,
                               CL_KERNEL_ARG_TYPE_NAME,
                               MAX_STRING_LENGTH,
                               &pString,
                               &size);
      ERROR(err, "clGetKernelArgInfo");
      printf("\tkernel arg type name: %s\n", pString);
    }
  }

  clReleaseCommandQueue(queue);
  clReleaseContext(context);
  
  return 0;
}
