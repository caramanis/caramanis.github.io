#include <stdlib.h>
#include <error.h>
#include <kernelio.h>
#include <string.h>

#define MAX_SOURCE_LENGTH 10000

void readSourceProgram(char* filename, unsigned char** source, size_t* length)
{
  FILE* input= fopen(filename, "rt");
  *length= 0;
  *source= (char*)malloc(sizeof(char)*MAX_SOURCE_LENGTH);
  while ( !feof(input) )
  {
    fgets(*source + *length, MAX_SOURCE_LENGTH, input);
    *length= strlen(*source);
  }
  *source= (char*)realloc(*source, sizeof(char)*strlen(*source));
}

void writeSourceProgram(char* filename, unsigned char* source)
{
  FILE* output= fopen(filename, "wt");
  fputs(source, output);
  fclose(output);
}

void writeBinaryProgram(char* filename, unsigned char** binaries, size_t* lengths, unsigned int n)
{
  FILE* output= fopen(filename, "wb");
  unsigned int i;
  
  fwrite(&n, sizeof(unsigned int), 1, output);
  for ( i= 0; i < n; ++i )
  {
    fwrite(lengths + i, sizeof(size_t), 1, output);
    fwrite(binaries[i], sizeof(unsigned char), lengths[i], output);
  }
  fclose(output);
}

void readBinaryProgram(char* filename, unsigned char*** binaries, size_t** lengths, unsigned int* n)
{
  FILE* input= fopen(filename, "rb");
  unsigned int i;
  
  fread(n, sizeof(unsigned int), 1, input);
  *lengths= (size_t*)malloc(sizeof(size_t)*(*n));
  *binaries= (unsigned char**)malloc(sizeof(unsigned char*)*(*n));
  for ( i= 0; i < *n; ++i )
  {
    fread(*lengths + i, sizeof(size_t), 1, input);
    (*binaries)[i]= (unsigned char*)malloc(sizeof(unsigned char)*(*(*lengths + i)));
    fread((*binaries)[i], sizeof(unsigned char), (*lengths)[i], input);
  }
  fclose(input);
}