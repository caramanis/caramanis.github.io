#include <stdio.h>
#include <error.h>
#include <CL/opencl.h>

#define ARRAY_SIZE 10
#define MAX_DEVICES 2
#define MAX_PLATFORMS 2

int main(int argc, char** argv)
{
  cl_int err;
  cl_context context;
  cl_command_queue queue;
  cl_mem memobj;
  cl_event event;
  cl_uint numPlatforms;
  cl_platform_id platforms[MAX_PLATFORMS];
  cl_uint numDevices;
  cl_device_id devices[MAX_DEVICES];
  cl_context_properties properties[3]= {0};
  size_t size;
  
  int input[ARRAY_SIZE], output[ARRAY_SIZE/2], i;
  
  for ( i= 0; i < ARRAY_SIZE; ++i )
    input[i]= i;

  err= clGetPlatformIDs(MAX_PLATFORMS, platforms, &numPlatforms);
  ERROR(err, "clGetPlatformIDs");
  
  properties[0]= (cl_context_properties)CL_CONTEXT_PLATFORM;
  properties[1]= (cl_context_properties)(platforms[0]);
  properties[2]= 0;
  
  context= clCreateContextFromType(properties, CL_DEVICE_TYPE_ALL, notify, &stderr, &err);
  ERROR(err, "clCreateContextFromType");
  
  err= clGetContextInfo(context, CL_CONTEXT_DEVICES, MAX_DEVICES*sizeof(cl_device_id), devices, &size);
  ERROR(err, "clGetContextInfo");
  
  err= clGetContextInfo(context, CL_CONTEXT_NUM_DEVICES, sizeof(cl_uint), &numDevices, &size);
  ERROR(err, "clGetContextInfo");
  
  queue= clCreateCommandQueue(context,             //context object
                              devices[0],          //device
                              0,                   //properties
                              &err);               //error code pointer
  ERROR(err, "clCreateCommandQueue");
  
  memobj= clCreateBuffer(context,                  //context object
                          CL_MEM_READ_WRITE,       //read and write grants
                          ARRAY_SIZE * sizeof(int),//size in bytes
                          NULL,                    //host_ptr
                          &err);                   //error code pointer
  ERROR(err, "clCreateBuffer");
  
  err= clEnqueueWriteBuffer(queue,                   //command queue
                            memobj,                  //buffer object
                            CL_TRUE,                 //blocking
                            0,                       //offset
                            sizeof(int)*ARRAY_SIZE,  //size in bytes
                            input,                   //input pointer
                            0,                       //number of events
                            NULL,                    //array of events
                            NULL);                   //output event pointer
  ERROR(err, "clEnqueueWriteBuffer");
  
  err= clEnqueueReadBuffer(queue,                       //command queue
                            memobj,                     //buffer object
                            CL_TRUE,                    //blocking
                            sizeof(int)*(ARRAY_SIZE/2), //offset
                            sizeof(int)*(ARRAY_SIZE/2), //size in bytes
                            output,                     //output pointer
                            0,                          //number of events
                            NULL,                       //array of events
                            NULL);                      //output event pointer
  ERROR(err, "clEnqueueReadBuffer");
  
  for ( i= 0; i < ARRAY_SIZE/2; ++i )
    printf("%d ", output[i]);
  printf("\n");
  
  clReleaseMemObject(memobj);
  clReleaseCommandQueue(queue);
  clReleaseContext(context);
  
  return 0;
}
