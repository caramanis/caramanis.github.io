#ifndef _PGM_H_
#define _PGM_H_

#include <stdio.h>

/** PGM kep beolvasasa
 * @param filename a beolvasando fajl neve
 * @param img a kepi informacio mutatoja ezen cimre irodik
 * @param rows a kep sorainak szama ezen cimre irodik
 * @param columns a kep oszlopainak szama ezen cimre irodik
 */ 
int readPGM(char* filename, float** img, unsigned int* rows, unsigned int* columns);

/** PGM kep kiirasa
 * @param filename a fajl neve
 * @param img a kiirando kep mutatoja
 * @param rows a kep sorainak szama
 * @param columns a kep oszlopainak szama
 */ 
int writePGM(char* filename, float* img, unsigned int rows, unsigned int columns);

#endif