#include <pgmio.h>
#include <stdio.h>
#include <float.h>
#include <string.h>
#include <stdlib.h>

/** A PGM fajl megjegyzes sorainak atugrasa
 * @param pgmFile A beolvasando pgm formatumu fajl mutatoja
 */ 
void skipComments(FILE* pgmFile)
{
  char ch;
  char line[1000];
  
  while ( fgets(line, sizeof(line), pgmFile) && line[0] == '#' );
  fseek(pgmFile, -strlen(line), SEEK_CUR);
}

int readPGM(char* filename, float** img, unsigned int* rows, unsigned int* columns)
{
  FILE* pgm;
  char version[3];
  int i, j, n;
  int maxGray;
  
  // fajl megnyitasa
  pgm= fopen(filename, "rb");
  if ( pgm == NULL )
  {
    printf("Nem sikerult megnyitni a fajlt olvasasra: %s\n!", filename);
    return -1;
  }
  // "MAGIC"-szam beolvasasa es ellenorzese
  fgets(version, sizeof(version), pgm);
  if ( strcmp(version, "P5") )
  {
    printf("A fajl nem P5-tipusu PGM.\n");
    return -1;
  }
  // leiro mezok beolvasasa
  skipComments(pgm);
  fscanf(pgm, "%d", columns);
  skipComments(pgm);
  fscanf(pgm, "%d", rows);
  skipComments(pgm);
  fscanf(pgm, "%d", &maxGray);
  fgetc(pgm);
  
  n= (*rows)*(*columns);
  
  // kep letrozasa
  (*img)= (float*)malloc(sizeof(float)*n);
  
  // kep tartalom beolvasasa
  for ( i= 0; i < n; ++i )
    (*img)[i]= (float)fgetc(pgm);
  
  fclose(pgm);
  
  return 0;
}

int writePGM(char* filename, float* img, unsigned int rows, unsigned int columns)
{
  FILE* pgm;
  int i, j;
  float minV= FLT_MAX, maxV= -FLT_MAX;
  int inm= rows * columns;
  unsigned char p;
  
  // minimum es maximum intenzitasok meghatarozasa
  for ( i= 0; i < inm; ++i )
  {
    if ( img[i] < minV )
      minV= img[i];
    if ( img[i] > maxV )
      maxV= img[i];
  }
  
  // fajl megnyitasa irasra
  pgm= fopen(filename, "wb");
  if ( pgm == NULL )
  {
    printf("Nem sikerult megnyitni a fajlt irasra: %s\n!", filename);
    return -1;
  }
  
  // "MAGIC" szam es leirok fajlba irasa
  fprintf(pgm, "P5 ");
  fprintf(pgm, "%d %d ", columns, rows);
  fprintf(pgm, "%d ", 255);

  // kep tartalom kiirasa
  for ( i= 0; i < inm; ++i )
    fputc((unsigned char)(img[i]-minV)/(maxV-minV)*255, pgm);
    
  fclose(pgm);
  
  return 0;
}
