#include <stdio.h>
#include <stdlib.h>
#include <pgmio.h>

int main(int argc, char** argv)
{
  unsigned int rows, columns;
  float* image;
  int i, tmp;
  
  readPGM(argv[1], &image, &rows, &columns);
  
  for ( i= 0; i < rows*columns; ++i )
  {
    image[i]= 255-image[i];
  }
  
  writePGM(argv[2], image, rows, columns);
  
  free(image);
  
  return 0;
}